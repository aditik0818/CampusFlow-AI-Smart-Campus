export type IssueCategory =
  | 'Infrastructure'
  | 'Internet/Wi-Fi'
  | 'Cleanliness'
  | 'Water'
  | 'Electrical'
  | 'Hostel'
  | 'Transport'
  | 'Security'
  | 'Lost & Found'
  | 'Other';

export type IssuePriority = 'Low' | 'Medium' | 'High' | 'Critical';

export type IssueStatus = 'Submitted' | 'Reviewed' | 'In Progress' | 'Resolved';

export type UserRole = 'student' | 'admin';

export interface IssueComment {
  id: string;
  author: string;
  text: string;
  createdAt: string;
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  category: IssueCategory;
  priority: IssuePriority;
  status: IssueStatus;
  location: string;
  locationDetail?: string;
  imageUrl?: string;
  studentName: string;
  studentEmail: string;
  createdAt: string;
  updatedAt: string;
  aiSummary: string;
  aiDepartment: string;
  aiConfidence?: number;
  isDuplicate?: boolean;
  duplicateOfId?: string;
  adminNotes?: string;
  resolutionDate?: string;
  assignedStaff?: string;
  upvotes?: number;
  comments?: IssueComment[];
}

export interface CampusLocation {
  id: string;
  name: string;
  buildingCode: string;
  xPercent: number; // 0 to 100 for SVG map
  yPercent: number;
  category: string;
  description: string;
}

export interface LostFoundItem {
  id: string;
  type: 'lost' | 'found';
  title: string;
  description: string;
  category: string;
  location: string;
  date: string;
  contactName: string;
  contactEmail: string;
  imageUrl?: string;
  status: 'open' | 'matched' | 'claimed';
  matchedItemId?: string;
  matchScore?: number;
  matchReason?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  department: string;
  priority: 'info' | 'warning' | 'urgent' | 'normal';
  date: string;
  author?: string;
}

export interface AIAnalysisResult {
  category: IssueCategory;
  priority: IssuePriority;
  summary: string;
  department: string;
  potentialDuplicate: {
    isDuplicate: boolean;
    similarityScore: number;
    existingIssueId?: string;
    existingIssueTitle?: string;
    reason?: string;
  } | null;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: { label: string; action: string }[];
}

export type ViewTab =
  | 'dashboard'
  | 'report'
  | 'my-complaints'
  | 'campus-map'
  | 'lost-found'
  | 'announcements'
  | 'admin-dashboard'
  | 'all-issues'
  | 'analytics';
