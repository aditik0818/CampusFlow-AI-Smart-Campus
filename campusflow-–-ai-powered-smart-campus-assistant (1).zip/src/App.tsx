import React, { useState, useEffect } from 'react';
import { 
  Issue, 
  LostFoundItem, 
  Announcement, 
  UserRole, 
  ViewTab, 
  IssueStatus 
} from './types';
import { 
  getStoredIssues, 
  saveStoredIssues, 
  getStoredLostFound, 
  saveStoredLostFound, 
  getStoredAnnouncements, 
  saveStoredAnnouncements 
} from './utils/storage';
import { CAMPUS_LOCATIONS } from './data/initialData';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { StudentDashboard } from './components/StudentDashboard';
import { ReportIssuePage } from './components/ReportIssuePage';
import { AdminDashboard } from './components/AdminDashboard';
import { CampusMap } from './components/CampusMap';
import { LostAndFoundPage } from './components/LostAndFoundPage';
import { MyComplaintsPage } from './components/MyComplaintsPage';
import { AnnouncementsPage } from './components/AnnouncementsPage';
import { IssueDetailModal } from './components/IssueDetailModal';
import { AIAssistantModal } from './components/AIAssistantModal';
import { Sparkles } from 'lucide-react';

export default function App() {
  // Global State
  const [issues, setIssues] = useState<Issue[]>([]);
  const [lostFound, setLostFound] = useState<LostFoundItem[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);

  // Navigation & Role State
  const [userRole, setUserRole] = useState<UserRole>('student');
  const [currentTab, setCurrentTab] = useState<ViewTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Modals & Assistant State
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [selectedDetailIssue, setSelectedDetailIssue] = useState<Issue | null>(null);

  // Notification Toast State
  const [notificationToast, setNotificationToast] = useState<{ message: string; type?: 'info' | 'success' } | null>(null);

  // Initialize data on mount
  useEffect(() => {
    const loadedIssues = getStoredIssues();
    const loadedLostFound = getStoredLostFound();
    const loadedAnnouncements = getStoredAnnouncements();

    setIssues(loadedIssues);
    setLostFound(loadedLostFound);
    setAnnouncements(loadedAnnouncements);
  }, []);

  // Show auto-dismissing toast
  const showToast = (message: string, type: 'info' | 'success' = 'success') => {
    setNotificationToast({ message, type });
    setTimeout(() => {
      setNotificationToast(null);
    }, 4000);
  };

  // Switch role with tab adjustment
  const handleRoleChange = (newRole: UserRole) => {
    setUserRole(newRole);
    if (newRole === 'admin') {
      setCurrentTab('admin-dashboard');
    } else {
      setCurrentTab('dashboard');
    }
  };

  const handleToggleRole = () => {
    handleRoleChange(userRole === 'student' ? 'admin' : 'student');
  };

  // Issue Handlers
  const handleCreateIssue = (newIssueData: Partial<Issue>) => {
    const created: Issue = {
      id: newIssueData.id || `CF-2026-${Math.floor(100 + Math.random() * 900)}`,
      title: newIssueData.title || 'Untitled Issue',
      description: newIssueData.description || '',
      category: newIssueData.category || 'Infrastructure',
      location: newIssueData.location || 'Campus Grounds',
      locationDetail: newIssueData.locationDetail,
      priority: newIssueData.priority || 'Medium',
      status: 'Submitted',
      imageUrl: newIssueData.imageUrl,
      studentName: newIssueData.studentName || 'Aditi Kumar',
      studentEmail: newIssueData.studentEmail || 'aditik0818@campus.edu',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      aiSummary: newIssueData.aiSummary || '',
      aiDepartment: newIssueData.aiDepartment || 'Campus Facilities',
      isDuplicate: newIssueData.isDuplicate,
      duplicateOfId: newIssueData.duplicateOfId,
      assignedStaff: newIssueData.aiDepartment ? 'Campus Operations Crew' : undefined,
      upvotes: 1,
      adminNotes: newIssueData.adminNotes,
      comments: [
        {
          id: `c-init-${Date.now()}`,
          author: 'CampusFlow AI Dispatcher',
          text: `Ticket generated and routed to ${newIssueData.aiDepartment || 'Campus Facilities'}.`,
          createdAt: new Date().toISOString(),
        },
      ],
    };

    const updated = [created, ...issues];
    setIssues(updated);
    saveStoredIssues(updated);
    showToast(`Issue #${created.id} submitted and dispatched successfully!`);
  };

  const handleUpdateIssueStatus = (issueId: string, newStatus: IssueStatus, adminNotes?: string) => {
    const updated = issues.map((issue) => {
      if (issue.id === issueId) {
        const resolutionDate = newStatus === 'Resolved' ? new Date().toISOString() : issue.resolutionDate;
        const newComments = [...(issue.comments || [])];
        if (adminNotes) {
          newComments.push({
            id: `c-${Date.now()}`,
            author: userRole === 'admin' ? 'Campus Dispatcher' : 'Technician',
            text: adminNotes,
            createdAt: new Date().toISOString(),
          });
        }
        return {
          ...issue,
          status: newStatus,
          adminNotes: adminNotes || issue.adminNotes,
          resolutionDate,
          updatedAt: new Date().toISOString(),
          comments: newComments,
        };
      }
      return issue;
    });

    setIssues(updated);
    saveStoredIssues(updated);

    if (selectedDetailIssue && selectedDetailIssue.id === issueId) {
      setSelectedDetailIssue(updated.find((i) => i.id === issueId) || null);
    }

    showToast(`Ticket #${issueId} status updated to "${newStatus}"`);
  };

  const handleUpvoteIssue = (issueId: string) => {
    const updated = issues.map((issue) => {
      if (issue.id === issueId) {
        return { ...issue, upvotes: (issue.upvotes || 0) + 1 };
      }
      return issue;
    });
    setIssues(updated);
    saveStoredIssues(updated);

    if (selectedDetailIssue && selectedDetailIssue.id === issueId) {
      setSelectedDetailIssue(updated.find((i) => i.id === issueId) || null);
    }
    showToast('Upvote recorded. This increases technician priority!');
  };

  const handleAddComment = (issueId: string, author: string, text: string) => {
    const updated = issues.map((issue) => {
      if (issue.id === issueId) {
        const newComments = [
          ...(issue.comments || []),
          {
            id: `comm-${Date.now()}`,
            author,
            text,
            createdAt: new Date().toISOString(),
          },
        ];
        return { ...issue, comments: newComments, updatedAt: new Date().toISOString() };
      }
      return issue;
    });

    setIssues(updated);
    saveStoredIssues(updated);

    if (selectedDetailIssue && selectedDetailIssue.id === issueId) {
      setSelectedDetailIssue(updated.find((i) => i.id === issueId) || null);
    }
  };

  // Lost & Found Handlers
  const handleAddLostFoundItem = (itemData: Partial<LostFoundItem>) => {
    const newItem: LostFoundItem = {
      id: itemData.id || `lf-${Date.now()}`,
      type: itemData.type || 'lost',
      title: itemData.title || '',
      description: itemData.description || '',
      category: itemData.category || 'General',
      location: itemData.location || 'Campus Grounds',
      date: itemData.date || new Date().toISOString().split('T')[0],
      contactName: itemData.contactName || 'Anonymous',
      contactEmail: itemData.contactEmail || 'student@campus.edu',
      status: 'open',
      imageUrl: itemData.imageUrl,
    };

    const updated = [newItem, ...lostFound];
    setLostFound(updated);
    saveStoredLostFound(updated);
    showToast(`${newItem.type === 'lost' ? 'Lost' : 'Found'} item logged into registry!`);
  };

  const handleClaimLostFoundItem = (itemId: string) => {
    const updated = lostFound.map((item) => {
      if (item.id === itemId) {
        return { ...item, status: 'claimed' as const };
      }
      return item;
    });
    setLostFound(updated);
    saveStoredLostFound(updated);
    showToast('Item marked as claimed and archived.');
  };

  // Announcements Handlers
  const handleAddAnnouncement = (announcementData: Partial<Announcement>) => {
    const newAnn: Announcement = {
      id: announcementData.id || `ann-${Date.now()}`,
      title: announcementData.title || '',
      content: announcementData.content || '',
      department: announcementData.department || 'Campus Administration',
      date: announcementData.date || new Date().toISOString().split('T')[0],
      priority: announcementData.priority || 'normal',
      author: announcementData.author || 'Operations Desk',
    };

    const updated = [newAnn, ...announcements];
    setAnnouncements(updated);
    saveStoredAnnouncements(updated);
    showToast('Campus bulletin broadcasted successfully!');
  };

  // Render current active tab
  const renderCurrentView = () => {
    switch (currentTab) {
      case 'dashboard':
        return (
          <StudentDashboard
            issues={issues}
            announcements={announcements}
            onSelectTab={setCurrentTab}
            onOpenIssueDetail={setSelectedDetailIssue}
            onUpvoteIssue={handleUpvoteIssue}
          />
        );

      case 'report':
        return (
          <ReportIssuePage
            locations={CAMPUS_LOCATIONS}
            existingIssues={issues}
            onSubmitIssue={handleCreateIssue}
            onSelectTab={setCurrentTab}
            onOpenExistingIssue={(id) => {
              const matched = issues.find((i) => i.id === id);
              if (matched) setSelectedDetailIssue(matched);
            }}
          />
        );

      case 'admin-dashboard':
        return (
          <AdminDashboard
            issues={issues}
            onUpdateIssueStatus={handleUpdateIssueStatus}
            onOpenIssueDetail={setSelectedDetailIssue}
            onSelectTab={setCurrentTab}
          />
        );

      case 'campus-map':
        return (
          <CampusMap
            locations={CAMPUS_LOCATIONS}
            issues={issues}
            onOpenIssueDetail={setSelectedDetailIssue}
            onReportForLocation={() => {
              setCurrentTab('report');
            }}
          />
        );

      case 'lost-found':
        return (
          <LostAndFoundPage
            items={lostFound}
            locations={CAMPUS_LOCATIONS}
            onAddItem={handleAddLostFoundItem}
            onClaimItem={handleClaimLostFoundItem}
          />
        );

      case 'my-complaints':
        return (
          <MyComplaintsPage
            issues={issues}
            onOpenIssueDetail={setSelectedDetailIssue}
            onSelectTab={setCurrentTab}
          />
        );

      case 'announcements':
        return (
          <AnnouncementsPage
            announcements={announcements}
            userRole={userRole}
            onAddAnnouncement={handleAddAnnouncement}
          />
        );

      default:
        return (
          <StudentDashboard
            issues={issues}
            announcements={announcements}
            onSelectTab={setCurrentTab}
            onOpenIssueDetail={setSelectedDetailIssue}
            onUpvoteIssue={handleUpvoteIssue}
          />
        );
    }
  };

  const myComplaintsCount = issues.filter((i) => i.studentEmail.includes('aditik')).length;
  const criticalCount = issues.filter((i) => i.priority === 'Critical' && i.status !== 'Resolved').length;

  return (
    <div className="min-h-screen w-full bg-slate-50 flex flex-col font-sans text-slate-900 antialiased selection:bg-indigo-500 selection:text-white overflow-x-hidden">
      {/* Top Fixed/Sticky Header */}
      <Header
        userRole={userRole}
        onRoleChange={handleRoleChange}
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        mobileMenuOpen={mobileMenuOpen}
        onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
        onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
        issues={issues}
      />

      {/* Main Layout Area: Fixed Sidebar + Fluid Content Area */}
      <div className="flex-1 flex relative w-full min-h-[calc(100vh-4rem)]">
        {/* Sidebar Navigation */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          userRole={userRole}
          mobileMenuOpen={mobileMenuOpen}
          onCloseMobile={() => setMobileMenuOpen(false)}
          onToggleRole={handleToggleRole}
          openIssuesCount={issues.filter((i) => i.status !== 'Resolved').length}
          criticalIssuesCount={criticalCount}
          myComplaintsCount={myComplaintsCount}
          onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
        />

        {/* Content Container (uses remaining width cleanly after fixed sidebar) */}
        <div className="flex-1 min-w-0 lg:pl-64 flex flex-col w-full">
          <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 min-w-0">
            {renderCurrentView()}
          </main>
        </div>
      </div>

      {/* Floating CampusFlow AI Button */}
      <button
        id="floating-ai-assistant-btn"
        type="button"
        onClick={() => setIsAiAssistantOpen(true)}
        className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 z-40 p-3.5 sm:px-4 sm:py-3 rounded-2xl bg-gradient-to-r from-indigo-700 via-indigo-800 to-slate-900 text-white shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2.5 border border-white/20 group cursor-pointer max-w-[calc(100vw-2.5rem)]"
        aria-label="Open CampusFlow AI Assistant"
      >
        <div className="relative shrink-0">
          <Sparkles className="w-5 h-5 text-indigo-200 group-hover:rotate-12 transition-transform" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
        </div>
        <span className="font-bold text-xs sm:text-sm tracking-tight hidden sm:inline truncate">
          CampusFlow AI
        </span>
      </button>

      {/* CampusFlow AI Floating Modal */}
      <AIAssistantModal
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
        issues={issues}
        announcements={announcements}
        lostFound={lostFound}
        onNavigateToTab={(tab) => {
          setCurrentTab(tab);
          setIsAiAssistantOpen(false);
        }}
      />

      {/* Issue Detail / Timeline / Admin Update Modal */}
      <IssueDetailModal
        issue={selectedDetailIssue}
        onClose={() => setSelectedDetailIssue(null)}
        userRole={userRole}
        onUpdateStatus={handleUpdateIssueStatus}
        onUpvote={handleUpvoteIssue}
        onAddComment={handleAddComment}
      />

      {/* Notification Toast */}
      {notificationToast && (
        <div className="fixed top-20 right-4 sm:right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 text-xs font-semibold flex items-center gap-2.5 animate-in fade-in slide-in-from-top-3 max-w-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="truncate">{notificationToast.message}</span>
        </div>
      )}
    </div>
  );
}
