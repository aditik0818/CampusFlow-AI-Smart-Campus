import { Issue, LostFoundItem, Announcement } from '../types';
import { INITIAL_ISSUES, INITIAL_LOST_FOUND, INITIAL_ANNOUNCEMENTS } from '../data/initialData';

const ISSUES_STORAGE_KEY = 'campusflow_issues_v1';
const LOST_FOUND_STORAGE_KEY = 'campusflow_lost_found_v1';
const ANNOUNCEMENTS_STORAGE_KEY = 'campusflow_announcements_v1';

export function getStoredIssues(): Issue[] {
  try {
    const data = localStorage.getItem(ISSUES_STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to parse stored issues, using defaults', e);
  }
  return INITIAL_ISSUES;
}

export function saveStoredIssues(issues: Issue[]): void {
  try {
    localStorage.setItem(ISSUES_STORAGE_KEY, JSON.stringify(issues));
  } catch (e) {
    console.warn('Failed to save issues to localStorage', e);
  }
}

export function getStoredLostFound(): LostFoundItem[] {
  try {
    const data = localStorage.getItem(LOST_FOUND_STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to parse stored lost & found, using defaults', e);
  }
  return INITIAL_LOST_FOUND;
}

export function saveStoredLostFound(items: LostFoundItem[]): void {
  try {
    localStorage.setItem(LOST_FOUND_STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.warn('Failed to save lost & found to localStorage', e);
  }
}

export function getStoredAnnouncements(): Announcement[] {
  try {
    const data = localStorage.getItem(ANNOUNCEMENTS_STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to parse announcements, using defaults', e);
  }
  return INITIAL_ANNOUNCEMENTS;
}

export function saveStoredAnnouncements(announcements: Announcement[]): void {
  try {
    localStorage.setItem(ANNOUNCEMENTS_STORAGE_KEY, JSON.stringify(announcements));
  } catch (e) {
    console.warn('Failed to save announcements to localStorage', e);
  }
}

export function resetDemoData(): void {
  localStorage.removeItem(ISSUES_STORAGE_KEY);
  localStorage.removeItem(LOST_FOUND_STORAGE_KEY);
  localStorage.removeItem(ANNOUNCEMENTS_STORAGE_KEY);
}
