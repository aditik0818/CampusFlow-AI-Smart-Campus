import React, { useState } from 'react';
import { Issue, IssueStatus, UserRole } from '../types';
import { 
  X, 
  MapPin, 
  Calendar, 
  User, 
  Sparkles, 
  Building2, 
  CheckCircle2, 
  Clock, 
  ThumbsUp, 
  MessageSquare, 
  Send,
  AlertTriangle,
  FileText
} from 'lucide-react';
import { PriorityBadge, StatusBadge, CategoryIcon } from './StatusBadge';
import { IssueTimeline } from './IssueTimeline';

interface IssueDetailModalProps {
  issue: Issue | null;
  onClose: () => void;
  userRole: UserRole;
  onUpdateStatus?: (issueId: string, status: IssueStatus, notes?: string) => void;
  onUpvote?: (issueId: string) => void;
  onAddComment?: (issueId: string, author: string, text: string) => void;
}

export const IssueDetailModal: React.FC<IssueDetailModalProps> = ({
  issue,
  onClose,
  userRole,
  onUpdateStatus,
  onUpvote,
  onAddComment,
}) => {
  const [commentText, setCommentText] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<IssueStatus>(issue?.status || 'Submitted');
  const [adminNote, setAdminNote] = useState(issue?.adminNotes || '');

  if (!issue) return null;

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !onAddComment) return;
    const authorName = userRole === 'admin' ? 'Campus Dispatch Ops' : 'Aditi Kumar (Student)';
    onAddComment(issue.id, authorName, commentText.trim());
    setCommentText('');
  };

  const handleStatusUpdate = () => {
    if (onUpdateStatus) {
      onUpdateStatus(issue.id, selectedStatus, adminNote.trim() || undefined);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[calc(100dvh-2rem)] overflow-hidden flex flex-col border border-slate-200 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-start justify-between gap-3 bg-slate-50/60">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="font-mono font-bold text-indigo-700">#{issue.id}</span>
              <span className="text-slate-400">•</span>
              <span className="font-medium text-slate-600">{issue.category}</span>
              <PriorityBadge priority={issue.priority} size="sm" />
              <StatusBadge status={issue.status} size="sm" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 mt-1.5 leading-snug">
              {issue.title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scroll Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-xs">
          
          {/* Timeline */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/70">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-2">
              Workflow Status Progression
            </span>
            <IssueTimeline
              currentStatus={issue.status}
              createdAt={issue.createdAt}
              updatedAt={issue.updatedAt}
              resolutionDate={issue.resolutionDate}
              assignedStaff={issue.assignedStaff}
            />
          </div>

          {/* Description & Location */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-4 text-slate-600">
              <span className="flex items-center gap-1.5 font-semibold text-slate-800">
                <MapPin className="w-4 h-4 text-indigo-600" />
                {issue.location} {issue.locationDetail && `(${issue.locationDetail})`}
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Reported {new Date(issue.createdAt).toLocaleString()}
              </span>
              <span className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-400" />
                {issue.studentName}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 text-slate-700 leading-relaxed text-xs sm:text-sm">
              {issue.description}
            </div>
          </div>

          {/* Uploaded Photo */}
          {issue.imageUrl && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Attached Issue Photograph
              </span>
              <div className="rounded-2xl overflow-hidden border border-slate-200 max-h-64 bg-slate-950 flex items-center justify-center">
                <img
                  src={issue.imageUrl}
                  alt={issue.title}
                  className="max-h-64 object-contain"
                />
              </div>
            </div>
          )}

          {/* AI Intelligence Diagnostics */}
          <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-indigo-900 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                AI Triage Diagnostic Record
              </span>
              <span className="text-[10px] text-indigo-700 font-mono">Gemini 2.5 Auto-Triage</span>
            </div>
            
            {issue.aiSummary && (
              <p className="text-slate-700 leading-relaxed">
                <strong>Executive Summary: </strong>
                {issue.aiSummary}
              </p>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-[11px]">
              <div className="p-2 rounded-xl bg-white/80 border border-indigo-100 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>
                  Dispatched To: <strong>{issue.aiDepartment || 'Facilities Management'}</strong>
                </span>
              </div>
              <div className="p-2 rounded-xl bg-white/80 border border-indigo-100 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>
                  Technician Assigned: <strong>{issue.assignedStaff || 'Pending Dispatch'}</strong>
                </span>
              </div>
            </div>

            {issue.isDuplicate && (
              <div className="p-2 rounded-xl bg-amber-100/70 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  Flagged as related to ticket <strong>#{issue.duplicateOfId}</strong>.
                </span>
              </div>
            )}
          </div>

          {/* Admin Management Section (If Admin Role) */}
          {userRole === 'admin' && onUpdateStatus && (
            <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-900 text-xs uppercase tracking-wider">
                  Admin Dispatch Controls
                </span>
                <span className="text-[11px] text-amber-700">Role: Operations Officer</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['Submitted', 'Reviewed', 'In Progress', 'Resolved'] as IssueStatus[]).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setSelectedStatus(st)}
                    className={`py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all ${
                      selectedStatus === st
                        ? 'border-indigo-600 bg-indigo-600 text-white'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-700">Internal Work Order / Resolution Note</label>
                <input
                  type="text"
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                  placeholder="e.g. Electrician scheduled for 2:00 PM today."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-white border border-slate-200"
                />
              </div>

              <button
                type="button"
                onClick={handleStatusUpdate}
                className="w-full py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs"
              >
                Save & Update Complaint Workflow
              </button>
            </div>
          )}

          {/* Student Upvote & Support Action */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="text-xs text-slate-600">
              Are you also experiencing this issue on campus?
            </div>
            {onUpvote && (
              <button
                type="button"
                onClick={() => onUpvote(issue.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 font-semibold text-xs border border-slate-200 shadow-xs transition-colors"
              >
                <ThumbsUp className="w-3.5 h-3.5 text-indigo-600" />
                Upvote ({issue.upvotes || 0})
              </button>
            )}
          </div>

          {/* Activity Comments Log */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Resolution Activity & Student Comments ({issue.comments?.length || 0})
            </h4>

            {issue.comments && issue.comments.length > 0 ? (
              <div className="space-y-2">
                {issue.comments.map((comment) => (
                  <div key={comment.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-slate-800">{comment.author}</span>
                      <span className="text-slate-400">{new Date(comment.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <p className="text-xs text-slate-600">{comment.text}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No notes posted yet.</p>
            )}

            {/* Post comment input */}
            {onAddComment && (
              <form onSubmit={handlePostComment} className="flex gap-2 pt-1">
                <input
                  type="text"
                  placeholder="Post a status inquiry or helpful detail..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  disabled={!commentText.trim()}
                  className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold disabled:opacity-40"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 flex items-center justify-end bg-slate-50/60">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition-colors"
          >
            Close Details
          </button>
        </div>

      </div>
    </div>
  );
};
