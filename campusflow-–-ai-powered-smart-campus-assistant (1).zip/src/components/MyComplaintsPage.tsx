import React, { useState } from 'react';
import { Issue, ViewTab } from '../types';
import { 
  FileText, 
  Search, 
  PlusCircle, 
  MapPin, 
  Calendar, 
  ChevronRight, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  Filter,
  Sparkles
} from 'lucide-react';
import { PriorityBadge, StatusBadge, CategoryIcon } from './StatusBadge';
import { IssueTimeline } from './IssueTimeline';

interface MyComplaintsPageProps {
  issues: Issue[];
  onOpenIssueDetail: (issue: Issue) => void;
  onSelectTab: (tab: ViewTab) => void;
}

export const MyComplaintsPage: React.FC<MyComplaintsPageProps> = ({
  issues,
  onOpenIssueDetail,
  onSelectTab,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  // Filter for student's complaints
  const studentIssues = issues.filter((i) => i.studentEmail.includes('aditik'));

  const filteredIssues = studentIssues.filter((issue) => {
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'All' || issue.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const pendingCount = studentIssues.filter((i) => i.status === 'Submitted').length;
  const inProgressCount = studentIssues.filter((i) => i.status === 'In Progress' || i.status === 'Reviewed').length;
  const resolvedCount = studentIssues.filter((i) => i.status === 'Resolved').length;

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
            <FileText className="w-3.5 h-3.5" />
            Student Complaint History
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mt-1">
            My Campus Complaints
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Track real-time progress on your submitted complaints, technician assignments, and resolution notes.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onSelectTab('report')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors"
        >
          <PlusCircle className="w-4 h-4" />
          Report New Issue
        </button>
      </div>

      {/* Mini Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Pending</span>
          <p className="text-xl sm:text-2xl font-bold text-blue-600 mt-1">{pendingCount}</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">In Progress</span>
          <p className="text-xl sm:text-2xl font-bold text-amber-600 mt-1">{inProgressCount}</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Resolved</span>
          <p className="text-xl sm:text-2xl font-bold text-emerald-600 mt-1">{resolvedCount}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search my tickets by keyword, ID, or location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-xs rounded-xl bg-white border border-slate-200 text-slate-700 focus:ring-2 focus:ring-indigo-500 font-medium"
        >
          <option value="All">All Statuses</option>
          <option value="Submitted">Submitted</option>
          <option value="Reviewed">Reviewed</option>
          <option value="In Progress">In Progress</option>
          <option value="Resolved">Resolved</option>
        </select>
      </div>

      {/* Complaints List with Inline Timelines */}
      <div className="space-y-4">
        {filteredIssues.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-white border border-slate-200 text-slate-500 space-y-2">
            <FileText className="w-10 h-10 text-slate-400 mx-auto" />
            <h4 className="text-sm font-bold text-slate-800">No complaints found</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              You have no complaints matching the filter. If you've observed a facility breakdown, feel free to report it!
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={() => onSelectTab('report')}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition-colors"
              >
                File a Complaint
              </button>
            </div>
          </div>
        ) : (
          filteredIssues.map((issue) => (
            <div
              key={issue.id}
              className="p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-indigo-200 shadow-xs space-y-4 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-mono font-bold text-indigo-700">
                      #{issue.id}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                      {issue.category}
                    </span>
                    <PriorityBadge priority={issue.priority} size="sm" />
                    <StatusBadge status={issue.status} size="sm" />
                  </div>

                  <h3
                    onClick={() => onOpenIssueDetail(issue)}
                    className="text-base font-bold text-slate-900 hover:text-indigo-600 transition-colors cursor-pointer"
                  >
                    {issue.title}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {issue.description}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-500">
                    <span className="flex items-center gap-1 font-medium text-slate-700">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {issue.location} {issue.locationDetail && `(${issue.locationDetail})`}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      Submitted {new Date(issue.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onOpenIssueDetail(issue)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 shrink-0 self-start sm:self-auto"
                >
                  View Details <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Status Timeline */}
              <div className="pt-2 border-t border-slate-100">
                <IssueTimeline
                  currentStatus={issue.status}
                  createdAt={issue.createdAt}
                  updatedAt={issue.updatedAt}
                  resolutionDate={issue.resolutionDate}
                  assignedStaff={issue.assignedStaff}
                />
              </div>

              {/* Admin Note if available */}
              {issue.adminNotes && (
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 flex items-start gap-2">
                  <span className="font-semibold text-indigo-900 shrink-0">Technician Dispatch Note:</span>
                  <span>{issue.adminNotes}</span>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
