import React, { useState } from 'react';
import { 
  Issue, 
  IssueStatus, 
  IssuePriority, 
  IssueCategory,
  ViewTab
} from '../types';
import { 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Filter, 
  Search, 
  Sparkles, 
  Layers, 
  BarChart3, 
  MapPin, 
  Calendar, 
  ArrowUpDown, 
  Edit3, 
  ChevronRight,
  UserCheck,
  TrendingUp,
  Download,
  AlertTriangle,
  Building2
} from 'lucide-react';
import { PriorityBadge, StatusBadge, CategoryIcon } from './StatusBadge';

interface AdminDashboardProps {
  issues: Issue[];
  onUpdateIssueStatus: (issueId: string, newStatus: IssueStatus, adminNotes?: string) => void;
  onOpenIssueDetail: (issue: Issue) => void;
  onSelectTab: (tab: ViewTab) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  issues,
  onUpdateIssueStatus,
  onOpenIssueDetail,
  onSelectTab,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState('All');
  const [selectedPriority, setSelectedPriority] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [sortField, setSortField] = useState<'createdAt' | 'priority' | 'status'>('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Status update modal state
  const [editingIssue, setEditingIssue] = useState<Issue | null>(null);
  const [newStatus, setNewStatus] = useState<IssueStatus>('In Progress');
  const [adminNoteInput, setAdminNoteInput] = useState('');

  // Stats
  const totalIssues = issues.length;
  const pendingCount = issues.filter((i) => i.status === 'Submitted').length;
  const inProgressCount = issues.filter((i) => i.status === 'In Progress' || i.status === 'Reviewed').length;
  const resolvedCount = issues.filter((i) => i.status === 'Resolved').length;
  const criticalCount = issues.filter((i) => i.priority === 'Critical').length;
  const highPriorityCount = issues.filter((i) => i.priority === 'High').length;

  // Priority issues (Critical & High)
  const priorityIssues = issues.filter(
    (i) => (i.priority === 'Critical' || i.priority === 'High') && i.status !== 'Resolved'
  );

  // Groupings for Charts
  // 1. By Category
  const categoryCounts: { [key: string]: number } = {};
  issues.forEach((i) => {
    categoryCounts[i.category] = (categoryCounts[i.category] || 0) + 1;
  });

  // 2. By Status
  const statusCounts = {
    Submitted: pendingCount,
    Reviewed: issues.filter((i) => i.status === 'Reviewed').length,
    'In Progress': issues.filter((i) => i.status === 'In Progress').length,
    Resolved: resolvedCount,
  };

  // 3. By Location (Hotspots)
  const locationCounts: { [key: string]: number } = {};
  issues.forEach((i) => {
    locationCounts[i.location] = (locationCounts[i.location] || 0) + 1;
  });
  const topLocations = Object.entries(locationCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // Filter issues for table
  const filteredIssues = issues.filter((issue) => {
    const matchesSearch =
      issue.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.studentName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || issue.category === selectedCategory;
    const matchesLocation = selectedLocation === 'All' || issue.location === selectedLocation;
    const matchesPriority = selectedPriority === 'All' || issue.priority === selectedPriority;
    const matchesStatus = selectedStatus === 'All' || issue.status === selectedStatus;
    return matchesSearch && matchesCategory && matchesLocation && matchesPriority && matchesStatus;
  });

  // Sort filtered issues
  const sortedIssues = [...filteredIssues].sort((a, b) => {
    if (sortField === 'createdAt') {
      const timeA = new Date(a.createdAt).getTime();
      const timeB = new Date(b.createdAt).getTime();
      return sortOrder === 'asc' ? timeA - timeB : timeB - timeA;
    }
    if (sortField === 'priority') {
      const weight: { [key in IssuePriority]: number } = { Critical: 4, High: 3, Medium: 2, Low: 1 };
      const diff = weight[a.priority] - weight[b.priority];
      return sortOrder === 'asc' ? diff : -diff;
    }
    return 0;
  });

  const handleOpenStatusModal = (issue: Issue) => {
    setEditingIssue(issue);
    setNewStatus(issue.status);
    setAdminNoteInput(issue.adminNotes || '');
  };

  const handleSaveStatusUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingIssue) {
      onUpdateIssueStatus(editingIssue.id, newStatus, adminNoteInput.trim() || undefined);
      setEditingIssue(null);
    }
  };

  const handleExportCSV = () => {
    const headers = ['ID', 'Title', 'Category', 'Location', 'Priority', 'Status', 'Date', 'Assigned Dept'];
    const rows = sortedIssues.map((i) => [
      i.id,
      `"${i.title.replace(/"/g, '""')}"`,
      i.category,
      `"${i.location}"`,
      i.priority,
      i.status,
      new Date(i.createdAt).toISOString().split('T')[0],
      `"${i.aiDepartment || ''}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `CampusFlow_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Banner & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
            <Layers className="w-3.5 h-3.5" />
            University Operations Console
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mt-1">
            Campus Administrator Dashboard
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Monitor incoming student grievance reports, view AI workload summaries, and update maintenance workflows.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs border border-slate-200 shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Export Audit CSV
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('campus-map')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors"
          >
            <MapPin className="w-3.5 h-3.5" />
            View Live Campus Map
          </button>
        </div>
      </div>

      {/* KPI Cards: Total, Pending, In Progress, Resolved, Critical */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Issues</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-bold text-slate-900">{totalIssues}</span>
            <span className="text-[11px] text-slate-400">All time</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Pending Review</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-bold text-blue-600">{pendingCount}</span>
            <span className="text-[11px] text-blue-500 font-medium">New tickets</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">In Progress</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-bold text-amber-600">{inProgressCount}</span>
            <span className="text-[11px] text-amber-500 font-medium">Active work</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Resolved</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-bold text-emerald-600">{resolvedCount}</span>
            <span className="text-[11px] text-emerald-600 font-medium">
              {totalIssues > 0 ? `${Math.round((resolvedCount / totalIssues) * 100)}%` : '0%'}
            </span>
          </div>
        </div>

        <div className="col-span-2 lg:col-span-1 bg-white p-4 rounded-2xl border border-rose-200 bg-rose-50/30 shadow-xs">
          <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
            Critical Issues
          </span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-bold text-rose-600">{criticalCount}</span>
            <span className="text-[11px] text-rose-600 font-semibold">Immediate Action</span>
          </div>
        </div>
      </div>

      {/* Priority Issues Spotlight Section */}
      {priorityIssues.length > 0 && (
        <div className="bg-white p-5 rounded-2xl border border-amber-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-600" />
              <h3 className="text-sm font-bold text-slate-900">
                Priority Action Items ({priorityIssues.length} High & Critical Incidents)
              </h3>
            </div>
            <span className="text-xs text-amber-700 font-medium hidden sm:inline">
              Requires administrative review
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            {priorityIssues.map((issue) => (
              <div
                key={issue.id}
                onClick={() => onOpenIssueDetail(issue)}
                className="p-3.5 rounded-xl bg-amber-50/50 hover:bg-amber-50 border border-amber-200/80 cursor-pointer transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-mono font-semibold text-slate-600">
                      #{issue.id}
                    </span>
                    <PriorityBadge priority={issue.priority} size="sm" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 mt-1">
                    {issue.title}
                  </h4>
                  <p className="text-[11px] text-slate-600 line-clamp-2 mt-0.5">
                    {issue.aiSummary || issue.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 mt-2 border-t border-amber-200/60 text-[11px] text-slate-500">
                  <span className="font-medium text-slate-700 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    {issue.location}
                  </span>
                  <StatusBadge status={issue.status} size="sm" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Interactive Analytics Charts (Category, Status, Location Hotspots, Timeline) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Chart 1: Issues by Category */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              Issues by Category
            </h3>
            <span className="text-[11px] text-slate-400">Total: {totalIssues}</span>
          </div>

          <div className="space-y-2 pt-1">
            {Object.entries(categoryCounts).map(([cat, count]) => {
              const pct = totalIssues > 0 ? Math.round((count / totalIssues) * 100) : 0;
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium text-slate-700">
                    <span className="flex items-center gap-1.5">
                      <CategoryIcon category={cat} className="w-3.5 h-3.5 text-slate-500" />
                      {cat}
                    </span>
                    <span className="font-semibold text-slate-900">
                      {count} <span className="text-[10px] text-slate-400 font-normal">({pct}%)</span>
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 2: Issues by Location (Hotspots) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-rose-500" />
              Frequently Reported Locations
            </h3>
            <span className="text-[11px] text-slate-400">Hotspots</span>
          </div>

          <div className="space-y-2.5 pt-1">
            {topLocations.map(([locName, count], idx) => {
              const maxCount = topLocations[0] ? topLocations[0][1] : 1;
              const pct = Math.round((count / maxCount) * 100);
              return (
                <div key={locName} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-[10px] font-bold">
                        {idx + 1}
                      </span>
                      {locName}
                    </span>
                    <span className="text-xs font-bold text-indigo-700">{count} reports</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-rose-500 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 3: Issues by Status & Resolution Velocity */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Workflow Status Breakdown
            </h3>
            <span className="text-[11px] text-emerald-700 font-semibold">Active Pipeline</span>
          </div>

          <div className="space-y-3 pt-1">
            {Object.entries(statusCounts).map(([status, count]) => {
              const pct = totalIssues > 0 ? Math.round((count / totalIssues) * 100) : 0;
              const barColor = {
                Submitted: 'bg-blue-500',
                Reviewed: 'bg-purple-500',
                'In Progress': 'bg-amber-500',
                Resolved: 'bg-emerald-500',
              }[status] || 'bg-slate-400';

              return (
                <div key={status} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium text-slate-700">
                    <span className="flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${barColor}`} />
                      {status}
                    </span>
                    <span className="font-semibold text-slate-900">
                      {count} <span className="text-[10px] text-slate-400 font-normal">({pct}%)</span>
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${barColor} rounded-full transition-all duration-500`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}

            <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
              <div className="font-semibold text-slate-800">Average Resolution Time:</div>
              <p className="mt-0.5 text-slate-500">
                Classroom AV & Wi-Fi: <strong>2.4 hrs</strong> • Civil & Plumbing: <strong>4.8 hrs</strong>
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* Main Issue Management Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden space-y-4 p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">Issue Management & Dispatch Table</h3>
            <p className="text-xs text-slate-500">Filter, search, review AI summaries, and update complaint status</p>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {sortedIssues.length} of {totalIssues} complaints
          </span>
        </div>

        {/* Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 pt-1">
          {/* Search */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by ID, keyword, or student..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 text-slate-800"
            />
          </div>

          {/* Category */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Categories</option>
            {Object.keys(categoryCounts).map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          {/* Priority */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Priorities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          {/* Status */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Statuses</option>
            <option value="Submitted">Submitted</option>
            <option value="Reviewed">Reviewed</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
          </select>
        </div>

        {/* Table View */}
        <div className="w-full overflow-x-auto rounded-xl border border-slate-200/80">
          <table className="w-full min-w-[760px] text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px] bg-slate-50">
                <th className="py-3 px-3">Complaint ID</th>
                <th className="py-3 px-3">Issue & AI Summary</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3">Location</th>
                <th className="py-3 px-3">Priority</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sortedIssues.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No complaints match the selected filters.
                  </td>
                </tr>
              ) : (
                sortedIssues.map((issue) => (
                  <tr
                    key={issue.id}
                    className="hover:bg-indigo-50/30 transition-colors group"
                  >
                    {/* Complaint ID */}
                    <td className="py-3.5 px-3 font-mono font-semibold text-indigo-700 whitespace-nowrap">
                      #{issue.id}
                    </td>

                    {/* Issue & AI Summary */}
                    <td className="py-3.5 px-3 max-w-sm">
                      <div 
                        onClick={() => onOpenIssueDetail(issue)}
                        className="cursor-pointer group-hover:text-indigo-600 transition-colors"
                      >
                        <p className="font-bold text-slate-900 leading-snug">
                          {issue.title}
                        </p>
                        {issue.aiSummary ? (
                          <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                            <span className="text-indigo-600 font-semibold">AI: </span>
                            {issue.aiSummary}
                          </p>
                        ) : (
                          <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                            {issue.description}
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Category */}
                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                        <CategoryIcon category={issue.category} className="w-3 h-3" />
                        {issue.category}
                      </span>
                    </td>

                    {/* Location */}
                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <div className="font-medium text-slate-800">{issue.location}</div>
                      {issue.locationDetail && (
                        <div className="text-[10px] text-slate-400">{issue.locationDetail}</div>
                      )}
                    </td>

                    {/* Priority */}
                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <PriorityBadge priority={issue.priority} size="sm" />
                    </td>

                    {/* Date */}
                    <td className="py-3.5 px-3 whitespace-nowrap text-slate-500">
                      {new Date(issue.createdAt).toLocaleDateString()}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <StatusBadge status={issue.status} size="sm" />
                    </td>

                    {/* Interactive Action */}
                    <td className="py-3.5 px-3 whitespace-nowrap text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenStatusModal(issue)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 font-semibold transition-colors flex items-center gap-1"
                          title="Change complaint status"
                        >
                          <Edit3 className="w-3 h-3" />
                          Update
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenIssueDetail(issue)}
                          className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
                          title="View Full Detail"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Status Update Modal */}
      {editingIssue && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h4 className="text-base font-bold text-slate-900">Update Complaint Status</h4>
                <p className="text-xs text-slate-500">Ticket #{editingIssue.id}</p>
              </div>
              <PriorityBadge priority={editingIssue.priority} size="sm" />
            </div>

            <p className="text-xs font-semibold text-slate-800">
              {editingIssue.title}
            </p>

            <form onSubmit={handleSaveStatusUpdate} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                  Select Workflow Status
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Submitted', 'Reviewed', 'In Progress', 'Resolved'] as IssueStatus[]).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setNewStatus(st)}
                      className={`p-2 rounded-xl text-xs font-semibold border transition-all text-left flex items-center justify-between ${
                        newStatus === st
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-900 ring-2 ring-indigo-200'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span>{st}</span>
                      {newStatus === st && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                  Technician / Resolution Note
                </label>
                <textarea
                  rows={3}
                  value={adminNoteInput}
                  onChange={(e) => setAdminNoteInput(e.target.value)}
                  placeholder="e.g., Work order assigned to Marcus. Xenon projector lamp replaced and tested."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingIssue(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs"
                >
                  Save & Dispatch Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
