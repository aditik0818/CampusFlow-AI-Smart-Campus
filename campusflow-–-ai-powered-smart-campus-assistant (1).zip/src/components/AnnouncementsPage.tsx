import React, { useState } from 'react';
import { Announcement, UserRole } from '../types';
import { 
  Megaphone, 
  Calendar, 
  Building2, 
  Search, 
  PlusCircle, 
  Tag, 
  CheckCircle2, 
  AlertTriangle, 
  Info,
  X
} from 'lucide-react';

interface AnnouncementsPageProps {
  announcements: Announcement[];
  userRole: UserRole;
  onAddAnnouncement: (announcement: Partial<Announcement>) => void;
}

export const AnnouncementsPage: React.FC<AnnouncementsPageProps> = ({
  announcements,
  userRole,
  onAddAnnouncement,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');
  const [showNewModal, setShowNewModal] = useState(false);

  // New announcement form state
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newDept, setNewDept] = useState('Campus IT Services');
  const [newPriority, setNewPriority] = useState<'normal' | 'urgent'>('normal');

  const departments = ['All', 'Campus IT Services', 'Hostel Administration', 'Facilities & Operations', 'Campus Security'];

  const filtered = announcements.filter((ann) => {
    const matchesSearch =
      ann.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ann.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = selectedDept === 'All' || ann.department === selectedDept;
    return matchesSearch && matchesDept;
  });

  const handleCreateAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    onAddAnnouncement({
      id: `ann-${Date.now()}`,
      title: newTitle.trim(),
      content: newContent.trim(),
      department: newDept,
      priority: newPriority,
      date: new Date().toISOString().split('T')[0],
      author: userRole === 'admin' ? 'Campus Administration' : 'Staff Officer',
    });

    setShowNewModal(false);
    setNewTitle('');
    setNewContent('');
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
            <Megaphone className="w-3.5 h-3.5" />
            University Broadcast System
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mt-1">
            Campus Bulletins & Notices
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Official announcements regarding scheduled facility maintenance, power outages, and network upgrades.
          </p>
        </div>

        {userRole === 'admin' && (
          <button
            type="button"
            onClick={() => setShowNewModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            Post New Bulletin
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search campus notices by title or keywords..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <select
          value={selectedDept}
          onChange={(e) => setSelectedDept(e.target.value)}
          className="px-3 py-2 text-xs rounded-xl bg-white border border-slate-200 text-slate-700 font-medium focus:ring-2 focus:ring-indigo-500"
        >
          {departments.map((dept) => (
            <option key={dept} value={dept}>{dept}</option>
          ))}
        </select>
      </div>

      {/* Announcements List */}
      <div className="space-y-4">
        {filtered.map((ann) => {
          const isUrgent = ann.priority === 'urgent';
          return (
            <div
              key={ann.id}
              className={`p-6 rounded-3xl border bg-white shadow-xs space-y-3 transition-all ${
                isUrgent ? 'border-amber-300 ring-1 ring-amber-200 bg-amber-50/20' : 'border-slate-200/80'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                      isUrgent
                        ? 'bg-amber-100 text-amber-900 border border-amber-300'
                        : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                    }`}
                  >
                    {isUrgent ? 'URGENT BULLETIN' : 'CAMPUS NOTICE'}
                  </span>
                  <span className="text-xs font-semibold text-slate-700 flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-slate-400" />
                    {ann.department}
                  </span>
                </div>

                <div className="flex items-center gap-1 text-xs text-slate-400">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{ann.date}</span>
                </div>
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-snug">
                {ann.title}
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed sm:text-sm">
                {ann.content}
              </p>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>Authorized by: {ann.author}</span>
                <span className="text-indigo-600 font-semibold">University Certified</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Post Bulletin Modal (Admin only) */}
      {showNewModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 border border-slate-200 shadow-xl space-y-4 max-h-[calc(100dvh-2rem)] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">Publish Campus Notice</h3>
              <button
                type="button"
                onClick={() => setShowNewModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAnnouncement} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-800">Bulletin Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Scheduled Wi-Fi maintenance window"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-800">Issuing Department</label>
                  <select
                    value={newDept}
                    onChange={(e) => setNewDept(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    <option value="Campus IT Services">Campus IT Services</option>
                    <option value="Hostel Administration">Hostel Administration</option>
                    <option value="Facilities & Operations">Facilities & Operations</option>
                    <option value="Campus Security">Campus Security</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-800">Priority Level</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    <option value="normal">Normal Notice</option>
                    <option value="urgent">Urgent Alert</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-800">Notice Body</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Details regarding buildings impacted, alternate facilities, and expected completion time..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs"
                >
                  Broadcast Bulletin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
