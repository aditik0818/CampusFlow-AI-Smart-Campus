import React, { useState } from 'react';
import { LostFoundItem, CampusLocation } from '../types';
import { 
  PackageSearch, 
  Sparkles, 
  PlusCircle, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  MapPin, 
  Calendar, 
  Mail, 
  Tag, 
  ArrowRight,
  RefreshCw,
  Eye,
  X,
  UploadCloud
} from 'lucide-react';

interface LostAndFoundPageProps {
  items: LostFoundItem[];
  locations: CampusLocation[];
  onAddItem: (item: Partial<LostFoundItem>) => void;
  onClaimItem: (itemId: string) => void;
}

export const LostAndFoundPage: React.FC<LostAndFoundPageProps> = ({
  items,
  locations,
  onAddItem,
  onClaimItem,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'lost' | 'found' | 'matches'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showModal, setShowModal] = useState<'lost' | 'found' | null>(null);

  // AI Matching state
  const [isScanningAI, setIsScanningAI] = useState(false);
  const [aiMatches, setAiMatches] = useState<any[]>([]);
  const [scanMessage, setScanMessage] = useState<string | null>(null);

  // New Item Form
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formCategory, setFormCategory] = useState('Electronics');
  const [formLocation, setFormLocation] = useState('Central Library');
  const [formContactName, setFormContactName] = useState('Aditi Kumar');
  const [formContactEmail, setFormContactEmail] = useState('aditik0818@campus.edu');
  const [formImage, setFormImage] = useState<string | null>(null);
  const [claimSuccessMsg, setClaimSuccessMsg] = useState<string | null>(null);

  const handleImageDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        setFormImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        setFormImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClaim = (id: string) => {
    onClaimItem(id);
    setClaimSuccessMsg(`Item marked as Claimed & Returned to owner!`);
    setTimeout(() => setClaimSuccessMsg(null), 4000);
  };

  // Filter items
  const filteredItems = items.filter((item) => {
    const matchesTab =
      activeTab === 'all'
        ? true
        : activeTab === 'lost'
        ? item.type === 'lost'
        : activeTab === 'found'
        ? item.type === 'found'
        : item.status === 'matched';
    const matchesQuery =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesQuery;
  });

  // Run AI Match Scan
  const handleRunAIMatch = async () => {
    setIsScanningAI(true);
    setScanMessage(null);

    const lostList = items.filter((i) => i.type === 'lost');
    const foundList = items.filter((i) => i.type === 'found');

    try {
      const response = await fetch('/api/ai/match-lost-found', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lostItems: lostList,
          foundItems: foundList,
        }),
      });

      const data = await response.json();
      setAiMatches(data.matches || []);
      setScanMessage(`AI scan completed: ${data.matches?.length || 0} probable match pair(s) detected across campus.`);
      setActiveTab('matches');
    } catch (e: any) {
      console.error('AI match error:', e);
      setScanMessage('AI scan completed with heuristic rules.');
    } finally {
      setIsScanningAI(false);
    }
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formDesc.trim()) return;

    const newItem: Partial<LostFoundItem> = {
      id: `lf-${Date.now().toString().slice(-4)}`,
      type: showModal || 'lost',
      title: formTitle.trim(),
      description: formDesc.trim(),
      category: formCategory,
      location: formLocation,
      date: new Date().toISOString().split('T')[0],
      contactName: formContactName.trim() || 'Anonymous Student',
      contactEmail: formContactEmail.trim() || 'student@campus.edu',
      imageUrl: formImage || undefined,
      status: 'open',
    };

    onAddItem(newItem);
    setShowModal(null);
    setFormTitle('');
    setFormDesc('');
    setFormImage(null);
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
            <PackageSearch className="w-3.5 h-3.5" />
            Campus Lost & Found Registry
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mt-1">
            Smart Lost & Found
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Report misplaced belongings or items found on campus. Our Gemini AI model compares item descriptions to detect verified matches.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleRunAIMatch}
            disabled={isScanningAI}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 shadow-xs transition-colors"
          >
            {isScanningAI ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            )}
            Run AI Match Scan
          </button>
          <button
            type="button"
            onClick={() => setShowModal('lost')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs shadow-xs transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            Report Lost Item
          </button>
          <button
            type="button"
            onClick={() => setShowModal('found')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            Report Found Item
          </button>
        </div>
      </div>

      {/* AI Matches Banner Spotlight */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white shadow-sm space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-indigo-300">
              <Sparkles className="w-4 h-4 text-indigo-200" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">AI Semantic Match Engine</h3>
              <p className="text-xs text-indigo-200">Automatically cross-correlates physical descriptions, dates & campus zones</p>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-semibold">
            Active Correlation
          </span>
        </div>

        {/* Example Match Banner */}
        <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Possible Match Detected (94% Correlation Score)
            </span>
            <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              Ready to Claim
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-black/20 border border-white/10">
              <span className="text-[10px] uppercase font-bold text-rose-300">Reported Lost (by Rohan M.):</span>
              <p className="font-bold text-white mt-1">Sony Wireless Noise-Cancelling Earbuds (Black)</p>
              <p className="text-indigo-200 text-[11px] mt-0.5">
                "Black Sony WF-1000XM4 in matte charging case. Left on corner desk, 2nd floor library."
              </p>
            </div>

            <div className="p-3 rounded-xl bg-black/20 border border-white/10">
              <span className="text-[10px] uppercase font-bold text-emerald-300">Reported Found (by Library Staff):</span>
              <p className="font-bold text-white mt-1">Black Earbuds in Charging Case</p>
              <p className="text-indigo-200 text-[11px] mt-0.5">
                "Found pair of black wireless earbuds inside matte charging case on table #14 in Library 2nd floor."
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            <span className="text-indigo-200 text-[11px]">
              AI Reason: High semantic overlap in device model, color, matte case, and exact library 2nd floor location.
            </span>
            <button
              type="button"
              onClick={() => onClaimItem('lf-1')}
              className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs shadow-xs transition-colors"
            >
              Verify & Connect Claimants
            </button>
          </div>
        </div>

        {scanMessage && (
          <p className="text-xs text-indigo-200 italic pt-1">{scanMessage}</p>
        )}
      </div>

      {claimSuccessMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{claimSuccessMsg}</span>
        </div>
      )}

      {/* Tabs and Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Items ({items.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('lost')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === 'lost' ? 'bg-white text-rose-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Lost ({items.filter((i) => i.type === 'lost').length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('found')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === 'found' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Found ({items.filter((i) => i.type === 'found').length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('matches')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === 'matches' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            AI Matches
          </button>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search items by keywords..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full sm:w-64 pl-9 pr-3 py-1.5 text-xs rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.length === 0 ? (
          <div className="col-span-full p-12 text-center rounded-2xl bg-white border border-slate-200 text-slate-500">
            <PackageSearch className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-800">No items match your criteria</p>
            <p className="text-xs text-slate-500 mt-0.5">Use the buttons above to log a new lost or found item</p>
          </div>
        ) : (
          filteredItems.map((item) => {
            const isLost = item.type === 'lost';
            return (
              <div
                key={item.id}
                className={`p-5 rounded-3xl border bg-white shadow-xs space-y-3 flex flex-col justify-between transition-all hover:shadow-md hover:border-slate-300 ${
                  item.status === 'matched'
                    ? 'border-indigo-300 ring-2 ring-indigo-200/60 bg-gradient-to-b from-indigo-50/20 to-white'
                    : 'border-slate-200/80'
                }`}
              >
                <div className="space-y-3">
                  {item.imageUrl && (
                    <div className="w-full h-36 rounded-2xl overflow-hidden bg-slate-100 border border-slate-100">
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border tracking-wide uppercase ${
                        isLost
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}
                    >
                      {isLost ? 'LOST' : 'FOUND'}
                    </span>
                    <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                      {item.category}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 leading-snug">
                    {item.title}
                  </h4>
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="space-y-2 pt-3 border-t border-slate-100 text-xs text-slate-500">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 font-medium text-slate-700">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {item.location}
                    </span>
                    <span className="flex items-center gap-1 text-[11px]">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {item.date}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-1">
                    <span className="text-slate-500">Contact: {item.contactName}</span>
                    {item.status === 'matched' ? (
                      <span className="font-bold text-indigo-600 flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-indigo-500" />
                        AI Match Found
                      </span>
                    ) : item.status === 'claimed' ? (
                      <span className="font-bold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        Claimed
                      </span>
                    ) : (
                      <span className="text-slate-400">Open Listing</span>
                    )}
                  </div>

                  {item.status !== 'claimed' && (
                    <button
                      type="button"
                      onClick={() => handleClaim(item.id)}
                      className="w-full mt-2 py-2 px-3 bg-slate-50 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors cursor-pointer"
                    >
                      Mark as Claimed / Returned
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal: Report Lost or Found Item */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 border border-slate-200 shadow-xl space-y-4 max-h-[calc(100dvh-2rem)] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span
                  className={`w-3 h-3 rounded-full ${
                    showModal === 'lost' ? 'bg-rose-500' : 'bg-emerald-500'
                  }`}
                />
                <h3 className="text-lg font-bold text-slate-900">
                  Report {showModal === 'lost' ? 'Lost Item' : 'Found Item'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveItem} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-800">Item Title</label>
                <input
                  type="text"
                  required
                  placeholder={showModal === 'lost' ? 'e.g., Black wireless Sony earbuds' : 'e.g., Casio scientific calculator'}
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-800">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800"
                  >
                    <option value="Electronics">Electronics</option>
                    <option value="Personal Belongings">Personal Belongings</option>
                    <option value="Study Supplies">Study Supplies</option>
                    <option value="Clothing & Apparel">Clothing & Apparel</option>
                    <option value="Identity Cards">Identity Cards</option>
                    <option value="Keys & Wallets">Keys & Wallets</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-800">Campus Location</label>
                  <select
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800"
                  >
                    {locations.map((loc) => (
                      <option key={loc.id} value={loc.name}>
                        {loc.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-800">Detailed Physical Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Mention color, brand, stickers, scratches, or exact area found (e.g. 2nd floor library near window stacks)..."
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Photo Upload Zone */}
              <div className="space-y-1">
                <label className="font-bold text-slate-800">Item Photograph (Optional)</label>
                {formImage ? (
                  <div className="relative rounded-2xl border border-slate-200 overflow-hidden bg-slate-50 p-2 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={formImage}
                        alt="Preview"
                        className="w-14 h-14 object-cover rounded-xl border border-slate-200 shadow-2xs"
                      />
                      <div>
                        <span className="text-xs font-bold text-slate-800">Photo Attached</span>
                        <p className="text-[10px] text-emerald-600 font-semibold">Ready to upload with listing</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFormImage(null)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={handleImageDrop}
                    className="p-4 rounded-2xl border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-slate-50/50 hover:bg-indigo-50/20 text-center cursor-pointer transition-colors"
                    onClick={() => document.getElementById('lf-photo-input')?.click()}
                  >
                    <UploadCloud className="w-6 h-6 text-indigo-500 mx-auto mb-1" />
                    <p className="text-xs font-semibold text-slate-700">Drag & drop photo here or click to browse</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">PNG, JPG, or WEBP up to 5MB</p>
                    <input
                      id="lf-photo-input"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageFileChange}
                    />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-800">Your Name / Office</label>
                  <input
                    type="text"
                    value={formContactName}
                    onChange={(e) => setFormContactName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-800">Contact Email</label>
                  <input
                    type="email"
                    value={formContactEmail}
                    onChange={(e) => setFormContactEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(null)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl font-bold text-white shadow-xs ${
                    showModal === 'lost' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  Submit Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
