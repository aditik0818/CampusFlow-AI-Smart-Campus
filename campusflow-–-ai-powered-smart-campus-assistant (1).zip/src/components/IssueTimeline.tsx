import React from 'react';
import { IssueStatus } from '../types';
import { Check, Clock, Eye, Wrench, CheckCircle2 } from 'lucide-react';

interface IssueTimelineProps {
  currentStatus: IssueStatus;
  createdAt?: string;
  updatedAt?: string;
  resolutionDate?: string;
  assignedStaff?: string;
}

const STEPS: { status: IssueStatus; label: string; description: string; icon: React.ComponentType<{ className?: string }> }[] = [
  {
    status: 'Submitted',
    label: 'Submitted',
    description: 'Complaint received & dispatched by AI triage',
    icon: Clock,
  },
  {
    status: 'Reviewed',
    label: 'Reviewed',
    description: 'Admin acknowledged & assigned department team',
    icon: Eye,
  },
  {
    status: 'In Progress',
    label: 'In Progress',
    description: 'Work order active; technician on campus',
    icon: Wrench,
  },
  {
    status: 'Resolved',
    label: 'Resolved',
    description: 'Inspected, tested and signed off as complete',
    icon: CheckCircle2,
  },
];

export const IssueTimeline: React.FC<IssueTimelineProps> = ({
  currentStatus,
  createdAt,
  updatedAt,
  resolutionDate,
  assignedStaff,
}) => {
  const statusOrder: IssueStatus[] = ['Submitted', 'Reviewed', 'In Progress', 'Resolved'];
  const currentIndex = statusOrder.indexOf(currentStatus);

  return (
    <div className="w-full py-4">
      <div className="relative">
        {/* Connecting Progress Line */}
        <div className="absolute top-5 left-6 right-6 h-0.5 bg-slate-200 -translate-y-1/2 z-0 hidden sm:block" />
        <div
          className="absolute top-5 left-6 h-0.5 bg-indigo-600 -translate-y-1/2 z-0 transition-all duration-500 hidden sm:block"
          style={{
            width: `${Math.max(0, (currentIndex / (STEPS.length - 1)) * 100 - 4)}%`,
          }}
        />

        {/* Timeline Nodes */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 sm:gap-2 relative z-10">
          {STEPS.map((step, idx) => {
            const isCompleted = idx < currentIndex;
            const isCurrent = idx === currentIndex;
            const isUpcoming = idx > currentIndex;
            const Icon = step.icon;

            return (
              <div key={step.status} className="flex sm:flex-col items-center sm:text-center group">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full font-semibold transition-all duration-300 border-2 ${
                    isCompleted
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                      : isCurrent
                      ? 'bg-white border-indigo-600 text-indigo-600 shadow-md ring-4 ring-indigo-50'
                      : 'bg-slate-100 border-slate-300 text-slate-400'
                  }`}
                >
                  {isCompleted ? <Check className="w-5 h-5 stroke-[2.5]" /> : <Icon className="w-5 h-5" />}
                </div>

                <div className="ml-3.5 sm:ml-0 sm:mt-2.5 flex-1">
                  <div className="flex sm:justify-center items-center gap-1.5">
                    <p
                      className={`text-sm font-semibold tracking-tight ${
                        isCurrent
                          ? 'text-indigo-950'
                          : isCompleted
                          ? 'text-slate-900'
                          : 'text-slate-400'
                      }`}
                    >
                      {step.label}
                    </p>
                    {isCurrent && (
                      <span className="inline-block w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
                    )}
                  </div>
                  <p className="text-xs text-slate-500 leading-tight mt-0.5 max-w-[170px] sm:mx-auto">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Meta context banner below timeline */}
      {(assignedStaff || resolutionDate || updatedAt) && (
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
          {assignedStaff && (
            <div className="flex items-center gap-1.5">
              <span className="font-medium text-slate-700">Assigned Handler:</span>
              <span className="px-2 py-0.5 bg-slate-100 rounded text-slate-800 font-medium">{assignedStaff}</span>
            </div>
          )}
          {isCurrentResolved(currentStatus) && resolutionDate && (
            <div className="text-emerald-700 font-medium">
              Resolved on {new Date(resolutionDate).toLocaleDateString()}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

function isCurrentResolved(status: IssueStatus): boolean {
  return status === 'Resolved';
}
