import React, { useState, useRef, useEffect } from 'react';
import { 
  Building2, 
  Sparkles, 
  User, 
  ShieldCheck, 
  Bell, 
  Menu, 
  X,
  CheckCircle2,
  Clock,
  Wifi,
  PackageSearch,
  Megaphone,
  Check,
  ChevronRight
} from 'lucide-react';
import { ViewTab, UserRole, Issue } from '../types';

interface HeaderProps {
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  currentTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  mobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
  onOpenAiAssistant: () => void;
  issues: Issue[];
}

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'wifi' | 'lost-found' | 'announcement' | 'status';
  read: boolean;
  actionTab?: ViewTab;
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Wi-Fi Ticket Update',
    message: 'Your Wi-Fi complaint is now In Progress.',
    time: '12m ago',
    type: 'wifi',
    read: false,
    actionTab: 'dashboard',
  },
  {
    id: 'notif-2',
    title: 'Lost Item Reviewed',
    message: 'Your lost ID card report has been reviewed.',
    time: '45m ago',
    type: 'lost-found',
    read: false,
    actionTab: 'lost-found',
  },
  {
    id: 'notif-3',
    title: 'Campus Bulletin',
    message: 'New campus announcement available: Library extended study hours.',
    time: '2h ago',
    type: 'announcement',
    read: false,
    actionTab: 'announcements',
  },
  {
    id: 'notif-4',
    title: 'Work Order Assigned',
    message: 'Technician dispatched for Classroom 302 projector issue.',
    time: '3h ago',
    type: 'status',
    read: true,
    actionTab: 'dashboard',
  },
];

export const Header: React.FC<HeaderProps> = ({
  userRole,
  onRoleChange,
  currentTab,
  onSelectTab,
  mobileMenuOpen,
  onToggleMobileMenu,
  onOpenAiAssistant,
  issues,
}) => {
  const isAdmin = userRole === 'admin';
  const openIssuesCount = issues.filter((i) => i.status !== 'Resolved').length;

  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [showNotifications, setShowNotifications] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMarkAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleNotificationClick = (notif: NotificationItem) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n))
    );
    if (notif.actionTab) {
      onSelectTab(notif.actionTab);
    }
    setShowNotifications(false);
  };

  const getNotifIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'wifi':
        return <Wifi className="w-3.5 h-3.5 text-cyan-600" />;
      case 'lost-found':
        return <PackageSearch className="w-3.5 h-3.5 text-amber-600" />;
      case 'announcement':
        return <Megaphone className="w-3.5 h-3.5 text-indigo-600" />;
      default:
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />;
    }
  };

  const getNotifBg = (type: NotificationItem['type']) => {
    switch (type) {
      case 'wifi':
        return 'bg-cyan-50 border-cyan-200';
      case 'lost-found':
        return 'bg-amber-50 border-amber-200';
      case 'announcement':
        return 'bg-indigo-50 border-indigo-200';
      default:
        return 'bg-emerald-50 border-emerald-200';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 w-full shrink-0">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-2 sm:gap-4">
          
          {/* Left: Brand & Mobile Menu Toggle */}
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button
              id="mobile-menu-toggle"
              type="button"
              onClick={onToggleMobileMenu}
              className="lg:hidden p-2 -ml-2 rounded-xl text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors focus:outline-hidden"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div 
              onClick={() => onSelectTab(isAdmin ? 'admin-dashboard' : 'dashboard')}
              className="flex items-center gap-2.5 cursor-pointer group select-none min-w-0"
            >
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-indigo-700 via-indigo-600 to-indigo-500 flex items-center justify-center text-white shadow-sm shadow-indigo-200 group-hover:scale-105 transition-transform shrink-0">
                <Building2 className="w-5 h-5" />
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-900 text-base sm:text-lg tracking-tight truncate">
                    CampusFlow
                  </span>
                  <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[10px] font-semibold tracking-wide border border-indigo-100 shrink-0">
                    <Sparkles className="w-2.5 h-2.5 text-indigo-600" />
                    AI
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 hidden md:block -mt-0.5 truncate">
                  Smart Campus Facility & Grievance Assistant
                </span>
              </div>
            </div>
          </div>

          {/* Center: Live Campus Status ticker (hidden on small viewports) */}
          <div className="hidden xl:flex items-center gap-3 px-3 py-1.5 rounded-full bg-slate-50 border border-slate-200/80 text-xs text-slate-600 shrink-0">
            <span className="flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="font-medium text-slate-700">Campus Grid:</span> Online
            </span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-500">
              <strong className="text-slate-800 font-semibold">{openIssuesCount}</strong> active reports
            </span>
          </div>

          {/* Right Action Bar */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">

            {/* Quick AI Assistant Trigger in Header */}
            <button
              id="header-ai-assistant-btn"
              type="button"
              onClick={onOpenAiAssistant}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold border border-indigo-200/70 transition-colors shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
              <span className="hidden sm:inline">Ask CampusFlow AI</span>
              <span className="sm:hidden">AI</span>
            </button>

            {/* Interactive Notifications Bell & Dropdown */}
            <div className="relative" ref={notifRef}>
              <button
                id="header-notifications-btn"
                type="button"
                onClick={() => setShowNotifications((prev) => !prev)}
                className={`relative p-2 rounded-xl text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors focus:outline-hidden ${
                  showNotifications ? 'bg-slate-100 text-indigo-700' : ''
                }`}
                title="Notifications"
                aria-label="Campus Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <>
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500" />
                  </>
                )}
              </button>

              {/* Notification Dropdown Panel */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl border border-slate-200/90 shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">Campus Alerts</span>
                      {unreadCount > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-bold">
                          {unreadCount} new
                        </span>
                      )}
                    </div>
                    {unreadCount > 0 && (
                      <button
                        type="button"
                        onClick={handleMarkAllAsRead}
                        className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Check className="w-3 h-3" />
                        Mark all read
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                    {notifications.map((notif) => (
                      <div
                        key={notif.id}
                        onClick={() => handleNotificationClick(notif)}
                        className={`p-3.5 flex items-start gap-3 hover:bg-slate-50/80 cursor-pointer transition-colors ${
                          !notif.read ? 'bg-indigo-50/25' : ''
                        }`}
                      >
                        <div className={`p-2 rounded-xl border shrink-0 ${getNotifBg(notif.type)}`}>
                          {getNotifIcon(notif.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1">
                            <h5 className="text-xs font-bold text-slate-900 truncate">
                              {notif.title}
                            </h5>
                            <span className="text-[10px] text-slate-400 shrink-0">
                              {notif.time}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 mt-0.5 leading-snug">
                            {notif.message}
                          </p>
                        </div>
                        {!notif.read && (
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 shrink-0 mt-2" />
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="p-2.5 bg-slate-50 border-t border-slate-100 text-center">
                    <button
                      type="button"
                      onClick={() => {
                        setShowNotifications(false);
                        onSelectTab('announcements');
                      }}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 inline-flex items-center gap-1 cursor-pointer"
                    >
                      View All Campus Bulletins
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Role Switcher (Student vs Admin) */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200/80">
              <button
                id="role-switch-student"
                type="button"
                onClick={() => {
                  if (isAdmin) onRoleChange('student');
                }}
                className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1 text-xs font-medium rounded-lg transition-all ${
                  !isAdmin
                    ? 'bg-white text-indigo-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Student</span>
              </button>
              <button
                id="role-switch-admin"
                type="button"
                onClick={() => {
                  if (!isAdmin) onRoleChange('admin');
                }}
                className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1 text-xs font-medium rounded-lg transition-all ${
                  isAdmin
                    ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            </div>

            {/* User Profile Avatar Pill */}
            <div className="hidden md:flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 font-bold text-xs border border-slate-200">
                {isAdmin ? 'AD' : 'AK'}
              </div>
              <div className="text-left leading-tight hidden lg:block">
                <p className="text-xs font-semibold text-slate-800">
                  {isAdmin ? 'Campus Admin' : 'Aditi Kumar'}
                </p>
                <p className="text-[10px] text-slate-400">
                  {isAdmin ? 'Facilities & Ops' : 'Computer Science'}
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>
    </header>
  );
};
