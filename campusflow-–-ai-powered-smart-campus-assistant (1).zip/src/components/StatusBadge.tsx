import React from 'react';
import { IssuePriority, IssueStatus, IssueCategory } from '../types';
import { 
  AlertTriangle, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Eye, 
  Shield, 
  Wifi, 
  Droplet, 
  Zap, 
  Building2, 
  Bus, 
  Trash2, 
  HelpCircle,
  Package
} from 'lucide-react';

interface PriorityBadgeProps {
  priority: IssuePriority;
  size?: 'sm' | 'md' | 'lg';
}

export const PriorityBadge: React.FC<PriorityBadgeProps> = ({ priority, size = 'md' }) => {
  const config = {
    Low: {
      bg: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
      dot: 'bg-emerald-500',
    },
    Medium: {
      bg: 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800',
      dot: 'bg-sky-500',
    },
    High: {
      bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
      dot: 'bg-amber-500',
    },
    Critical: {
      bg: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800 font-semibold',
      dot: 'bg-rose-500 animate-pulse',
    },
  }[priority] || {
    bg: 'bg-slate-50 text-slate-700 border-slate-200',
    dot: 'bg-slate-500',
  };

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
    lg: 'text-sm px-3 py-1.5',
  }[size];

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border ${config.bg} ${sizeClasses} font-medium tracking-wide whitespace-nowrap`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />
      {priority}
    </span>
  );
};

interface StatusBadgeProps {
  status: IssueStatus;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const config = {
    Submitted: {
      bg: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800',
      icon: Clock,
      label: 'Submitted',
    },
    Reviewed: {
      bg: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800',
      icon: Eye,
      label: 'Reviewed',
    },
    'In Progress': {
      bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
      icon: AlertCircle,
      label: 'In Progress',
    },
    Resolved: {
      bg: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
      icon: CheckCircle2,
      label: 'Resolved',
    },
  }[status] || {
    bg: 'bg-slate-50 text-slate-700 border-slate-200',
    icon: Clock,
    label: status,
  };

  const Icon = config.icon;
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
    lg: 'text-sm px-3 py-1.5',
  }[size];

  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4',
  }[size];

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border ${config.bg} ${sizeClasses} font-medium tracking-wide whitespace-nowrap`}
    >
      <Icon className={iconSizes} />
      {config.label}
    </span>
  );
};

export const CategoryIcon: React.FC<{ category: IssueCategory | string; className?: string }> = ({
  category,
  className = 'w-4 h-4',
}) => {
  switch (category) {
    case 'Infrastructure':
      return <Building2 className={className} />;
    case 'Internet/Wi-Fi':
      return <Wifi className={className} />;
    case 'Cleanliness':
      return <Trash2 className={className} />;
    case 'Water':
      return <Droplet className={className} />;
    case 'Electrical':
      return <Zap className={className} />;
    case 'Hostel':
      return <Building2 className={className} />;
    case 'Transport':
      return <Bus className={className} />;
    case 'Security':
      return <Shield className={className} />;
    case 'Lost & Found':
      return <Package className={className} />;
    default:
      return <HelpCircle className={className} />;
  }
};
