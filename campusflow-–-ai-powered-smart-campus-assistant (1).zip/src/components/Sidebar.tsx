import React from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  ClipboardList, 
  MapPin, 
  PackageSearch, 
  Bell, 
  Layers, 
  Sparkles, 
  ShieldAlert,
  ArrowRightLeft,
  X
} from 'lucide-react';
import { ViewTab, UserRole } from '../types';

interface SidebarProps {
  userRole: UserRole;
  currentTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  mobileMenuOpen: boolean;
  onCloseMobile: () => void;
  onToggleRole: () => void;
  openIssuesCount: number;
  criticalIssuesCount: number;
  myComplaintsCount: number;
  onOpenAiAssistant: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  userRole,
  currentTab,
  onSelectTab,
  mobileMenuOpen,
  onCloseMobile,
  onToggleRole,
  openIssuesCount,
  criticalIssuesCount,
  myComplaintsCount,
  onOpenAiAssistant,
}) => {
  const isAdmin = userRole === 'admin';

  const studentNavItems: {
    id: ViewTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string | number;
    badgeColor?: string;
  }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'report', label: 'Report Issue', icon: PlusCircle, badge: 'AI', badgeColor: 'bg-indigo-100 text-indigo-700' },
    { id: 'my-complaints', label: 'My Complaints', icon: ClipboardList, badge: myComplaintsCount || undefined, badgeColor: 'bg-slate-100 text-slate-700' },
    { id: 'campus-map', label: 'Campus Map', icon: MapPin },
    { id: 'lost-found', label: 'Lost & Found', icon: PackageSearch, badge: 'Match', badgeColor: 'bg-emerald-100 text-emerald-700' },
    { id: 'announcements', label: 'Announcements', icon: Bell },
  ];

  const adminNavItems: {
    id: ViewTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string | number;
    badgeColor?: string;
  }[] = [
    { id: 'admin-dashboard', label: 'Admin Console', icon: LayoutDashboard },
    { id: 'campus-map', label: 'Campus Map', icon: MapPin },
    { id: 'lost-found', label: 'Lost & Found', icon: PackageSearch },
    { id: 'announcements', label: 'Announcements', icon: Bell },
    { id: 'report', label: 'File Complaint', icon: PlusCircle },
  ];

  const items = isAdmin ? adminNavItems : studentNavItems;

  const handleNavClick = (tab: ViewTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200/80 p-4 flex flex-col justify-between overflow-y-auto transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        <div className="space-y-5">
          
          {/* Mobile close button header */}
          <div className="flex items-center justify-between lg:hidden pb-1 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Navigation Menu
            </span>
            <button
              type="button"
              onClick={onCloseMobile}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Mode label tag & role switcher */}
          <div className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between shadow-2xs">
            <div className="flex items-center gap-2">
              <span
                className={`w-2 h-2 rounded-full ${
                  isAdmin ? 'bg-indigo-600 ring-2 ring-indigo-200' : 'bg-emerald-500 ring-2 ring-emerald-200'
                }`}
              />
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                {isAdmin ? 'Admin View' : 'Student View'}
              </span>
            </div>
            <button
              type="button"
              onClick={onToggleRole}
              className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
              title="Switch user view"
            >
              <ArrowRightLeft className="w-3 h-3" />
              Switch
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            <div className="px-3 pb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Campus Flow Menu
            </div>
            {items.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;

              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  type="button"
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-white' : 'text-slate-500 group-hover:text-slate-700'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  {item.badge !== undefined && (
                    <span
                      className={`text-[11px] px-2 py-0.5 rounded-full font-semibold shrink-0 ${
                        isActive ? 'bg-white/20 text-white' : item.badgeColor || 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Critical Incident Alert Banner in Sidebar */}
          {criticalIssuesCount > 0 && (
            <div className="p-3 rounded-xl bg-rose-50/80 border border-rose-200 text-rose-800 space-y-1">
              <div className="flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-rose-900">
                  Priority Action
                </span>
              </div>
              <p className="text-xs text-rose-700 leading-snug">
                {criticalIssuesCount} critical incident{criticalIssuesCount > 1 ? 's' : ''} reported on campus.
              </p>
              <button
                type="button"
                onClick={() => handleNavClick(isAdmin ? 'admin-dashboard' : 'dashboard')}
                className="text-xs font-semibold text-rose-900 hover:underline pt-0.5 block"
              >
                Inspect tickets →
              </button>
            </div>
          )}
        </div>

        {/* Bottom AI Assistant CTA */}
        <div className="space-y-3 pt-4 border-t border-slate-100">
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-50 via-slate-50 to-indigo-50/50 border border-indigo-100/80 shadow-2xs">
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white shrink-0 shadow-xs">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-slate-900 leading-snug truncate">CampusFlow AI</p>
                <p className="text-[11px] text-slate-500 leading-tight mt-0.5">
                  Instant guidance & automated complaint triage.
                </p>
              </div>
            </div>
            <button
              id="sidebar-ask-ai-btn"
              type="button"
              onClick={() => {
                onOpenAiAssistant();
                onCloseMobile();
              }}
              className="mt-2.5 w-full py-1.5 px-3 bg-white hover:bg-slate-50 text-indigo-700 border border-indigo-200 text-xs font-semibold rounded-lg shadow-2xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              Launch Assistant
            </button>
          </div>

          <div className="text-[10px] text-slate-400 text-center tracking-tight">
            CampusFlow v2.4 • Smart University
          </div>
        </div>
      </aside>
    </>
  );
};
