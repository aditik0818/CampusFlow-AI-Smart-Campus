import React, { useState } from 'react';
import { Issue, CampusLocation, IssuePriority } from '../types';
import { 
  MapPin, 
  Building2, 
  Layers, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Filter, 
  Info, 
  ChevronRight,
  Eye,
  Sparkles,
  Compass,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  PlusCircle,
  TreePine,
  Coffee,
  BookOpen,
  Trophy,
  Bed,
  Laptop
} from 'lucide-react';
import { PriorityBadge, StatusBadge, CategoryIcon } from './StatusBadge';

interface CampusMapProps {
  locations: CampusLocation[];
  issues: Issue[];
  onOpenIssueDetail: (issue: Issue) => void;
  onReportForLocation?: (locationName: string) => void;
}

export const CampusMap: React.FC<CampusMapProps> = ({
  locations,
  issues,
  onOpenIssueDetail,
  onReportForLocation,
}) => {
  const [selectedLocation, setSelectedLocation] = useState<CampusLocation | null>(null);
  const [selectedZone, setSelectedZone] = useState<string>('All');
  const [filterPriority, setFilterPriority] = useState<string>('All');
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('Open');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  const zones = [
    { label: 'All Campus', value: 'All', icon: Compass },
    { label: 'Academic & Labs', value: 'Academic', icon: Laptop },
    { label: 'Library & Quad', value: 'Library', icon: BookOpen },
    { label: 'Hostel Village', value: 'Hostel', icon: Bed },
    { label: 'Dining & Canteen', value: 'Dining', icon: Coffee },
    { label: 'Sports & Grounds', value: 'Sports', icon: Trophy },
  ];

  // Filter issues
  const filteredIssues = issues.filter((issue) => {
    const matchesPriority = filterPriority === 'All' || issue.priority === filterPriority;
    const matchesCategory = filterCategory === 'All' || issue.category === filterCategory;
    const matchesStatus =
      filterStatus === 'All'
        ? true
        : filterStatus === 'Open'
        ? issue.status !== 'Resolved'
        : issue.status === 'Resolved';
    
    let matchesZone = true;
    if (selectedZone !== 'All') {
      const loc = locations.find((l) => l.name.toLowerCase().includes(issue.location.toLowerCase()) || issue.location.toLowerCase().includes(l.name.toLowerCase()));
      if (loc) {
        matchesZone = loc.category.toLowerCase().includes(selectedZone.toLowerCase()) || loc.name.toLowerCase().includes(selectedZone.toLowerCase());
      }
    }

    return matchesPriority && matchesCategory && matchesStatus && matchesZone;
  });

  // Group issues by location
  const issuesByLocation: { [locName: string]: Issue[] } = {};
  filteredIssues.forEach((issue) => {
    const matchedLoc = locations.find(
      (l) => l.name.toLowerCase().includes(issue.location.toLowerCase()) || issue.location.toLowerCase().includes(l.name.toLowerCase())
    );
    const key = matchedLoc ? matchedLoc.name : issue.location;
    if (!issuesByLocation[key]) {
      issuesByLocation[key] = [];
    }
    issuesByLocation[key].push(issue);
  });

  const getPinColor = (locationIssues: Issue[]) => {
    if (locationIssues.some((i) => i.priority === 'Critical')) {
      return { bg: 'bg-rose-500', ring: 'ring-rose-200', text: 'text-white' };
    }
    if (locationIssues.some((i) => i.priority === 'High')) {
      return { bg: 'bg-amber-500', ring: 'ring-amber-200', text: 'text-white' };
    }
    if (locationIssues.some((i) => i.priority === 'Medium')) {
      return { bg: 'bg-sky-500', ring: 'ring-sky-200', text: 'text-white' };
    }
    return { bg: 'bg-emerald-500', ring: 'ring-emerald-200', text: 'text-white' };
  };

  const handleZoom = (delta: number) => {
    setZoomLevel((prev) => Math.min(Math.max(Number((prev + delta).toFixed(2)), 0.9), 1.6));
  };

  const categories = ['All', 'Infrastructure', 'Internet/Wi-Fi', 'Cleanliness', 'Water', 'Electrical', 'Hostel', 'Transport', 'Lost & Found'];

  return (
    <div className="space-y-6 pb-16">
      {/* Map Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
            <Compass className="w-3.5 h-3.5 text-indigo-600" />
            Interactive Spatial Campus GIS
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Campus Live Incident Map
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Real-time visual map of university buildings and grounds. Click any marker or building to inspect active issues.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2.5">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs focus:ring-2 focus:ring-indigo-500"
          >
            <option value="Open">Active Issues (Open)</option>
            <option value="Resolved">Resolved Issues</option>
            <option value="All">All Statuses</option>
          </select>

          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Categories</option>
            {categories.filter(c => c !== 'All').map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-medium text-slate-700 shadow-2xs focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Priorities</option>
            <option value="Critical">Critical Only</option>
            <option value="High">High Only</option>
            <option value="Medium">Medium Only</option>
            <option value="Low">Low Only</option>
          </select>
        </div>
      </div>

      {/* Campus Zone Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
        {zones.map((zone) => {
          const Icon = zone.icon;
          const isSelected = selectedZone === zone.value;
          return (
            <button
              key={zone.value}
              type="button"
              onClick={() => setSelectedZone(zone.value)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-semibold whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-indigo-900 text-white shadow-xs'
                  : 'bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-300' : 'text-slate-400'}`} />
              <span>{zone.label}</span>
            </button>
          );
        })}
      </div>

      {/* Map Card & Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left 3 Cols: SVG Interactive Canvas Map */}
        <div className="lg:col-span-3 min-w-0 bg-white p-4 sm:p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
          
          {/* Map Legend & Zoom Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs pb-2 border-b border-slate-100">
            <div className="flex flex-wrap items-center gap-3 sm:gap-4">
              <span className="font-bold text-slate-700">Incident Severity:</span>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                <span className="text-slate-600 font-medium">Critical</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <span className="text-slate-600 font-medium">High</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                <span className="text-slate-600 font-medium">Medium</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span className="text-slate-600 font-medium">Low / None</span>
              </div>
            </div>

            {/* Map Zoom Controls */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => handleZoom(-0.15)}
                className="p-1.5 rounded-lg hover:bg-white text-slate-600 hover:text-slate-900 transition-colors"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="px-1.5 text-[11px] font-mono font-bold text-slate-600">
                {Math.round(zoomLevel * 100)}%
              </span>
              <button
                type="button"
                onClick={() => handleZoom(0.15)}
                className="p-1.5 rounded-lg hover:bg-white text-slate-600 hover:text-slate-900 transition-colors"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setZoomLevel(1)}
                className="p-1.5 rounded-lg hover:bg-white text-slate-600 hover:text-slate-900 transition-colors ml-1"
                title="Reset Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive Campus SVG Layout with Zoom scale */}
          <div className="relative w-full aspect-16/10 min-h-[340px] sm:min-h-[460px] max-h-[600px] rounded-3xl bg-gradient-to-br from-emerald-50/40 via-slate-50 to-indigo-50/40 border border-slate-200 overflow-hidden select-none">
            
            <div
              style={{
                transform: `scale(${zoomLevel})`,
                transformOrigin: 'center center',
                transition: 'transform 200ms ease-out',
                width: '100%',
                height: '100%',
                position: 'relative'
              }}
            >
              {/* SVG Background: Pathways, Lawns, and Building Footprints */}
              <svg
                className="absolute inset-0 w-full h-full"
                viewBox="0 0 1000 600"
                preserveAspectRatio="none"
              >
                {/* Campus perimeter lawn */}
                <rect x="0" y="0" width="1000" height="600" fill="#f8fafc" />

                {/* Park & Grass areas */}
                <circle cx="200" cy="400" r="140" fill="#ecfdf5" opacity="0.85" />
                <rect x="680" y="320" width="280" height="240" rx="30" fill="#f0fdf4" opacity="0.9" />
                <circle cx="820" cy="420" r="100" fill="#dcfce7" opacity="0.7" stroke="#bbf7d0" strokeWidth="2" strokeDasharray="6 4" />

                {/* Illustrated Campus Ring Road */}
                <path
                  d="M 120 540 L 120 180 Q 120 100 200 100 L 800 100 Q 880 100 880 180 L 880 500 Q 880 540 800 540 L 120 540 Z"
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth="32"
                  strokeLinejoin="round"
                />
                <path
                  d="M 120 540 L 120 180 Q 120 100 200 100 L 800 100 Q 880 100 880 180 L 880 500 Q 880 540 800 540 L 120 540 Z"
                  fill="none"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                  strokeDasharray="12 8"
                />

                {/* Central boulevard & walk paths */}
                <path
                  d="M 120 500 L 500 350 L 850 350"
                  fill="none"
                  stroke="#cbd5e1"
                  strokeWidth="14"
                  strokeLinecap="round"
                />
                <path
                  d="M 360 200 L 360 420 L 550 420"
                  fill="none"
                  stroke="#94a3b8"
                  strokeWidth="8"
                  strokeDasharray="6 4"
                />

                {/* Zone Labels */}
                <text x="500" y="70" textAnchor="middle" fill="#94a3b8" fontSize="12" fontWeight="700" letterSpacing="2">
                  NORTH ACADEMIC QUAD
                </text>
                <text x="820" y="300" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="700" letterSpacing="1.5">
                  VILLAGE & SPORTS
                </text>
                <text x="200" y="560" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="700" letterSpacing="1.5">
                  CAMPUS MAIN GATE
                </text>

                {/* Building Footprint Boxes */}
                {locations.map((loc) => {
                  const cx = (loc.xPercent / 100) * 1000;
                  const cy = (loc.yPercent / 100) * 600;
                  const isSelected = selectedLocation?.id === loc.id;
                  
                  return (
                    <g key={loc.id} className="cursor-pointer">
                      {/* Footprint shadow */}
                      <rect
                        x={cx - 56}
                        y={cy - 34}
                        width="114"
                        height="72"
                        rx="14"
                        fill="#0f172a"
                        opacity="0.04"
                      />
                      {/* Footprint block */}
                      <rect
                        x={cx - 55}
                        y={cy - 35}
                        width="110"
                        height="70"
                        rx="14"
                        fill={isSelected ? '#e0e7ff' : '#ffffff'}
                        stroke={isSelected ? '#4f46e5' : '#cbd5e1'}
                        strokeWidth={isSelected ? 3 : 1.5}
                        className="transition-colors hover:fill-indigo-50"
                        onClick={() => {
                          setSelectedLocation(loc);
                        }}
                      />
                      {/* Building code */}
                      <text
                        x={cx}
                        y={cy - 12}
                        textAnchor="middle"
                        fill="#6366f1"
                        fontSize="10"
                        fontWeight="bold"
                      >
                        {loc.buildingCode}
                      </text>
                      {/* Building name */}
                      <text
                        x={cx}
                        y={cy + 8}
                        textAnchor="middle"
                        fill="#0f172a"
                        fontSize="11"
                        fontWeight="700"
                      >
                        {loc.name.length > 15 ? `${loc.name.slice(0, 13)}…` : loc.name}
                      </text>
                    </g>
                  );
                })}
              </svg>

              {/* Floating Issue Markers */}
              {locations.map((loc) => {
                const locIssues = issuesByLocation[loc.name] || [];
                const count = locIssues.length;
                if (count === 0) return null;

                const pinTheme = getPinColor(locIssues);
                const hasCritical = locIssues.some((i) => i.priority === 'Critical');

                return (
                  <div
                    key={`pin-${loc.id}`}
                    style={{
                      left: `${loc.xPercent}%`,
                      top: `${loc.yPercent}%`,
                      transform: 'translate(-50%, -50%)',
                    }}
                    className="absolute z-20 cursor-pointer"
                    onClick={() => {
                      setSelectedLocation(loc);
                    }}
                  >
                    <div className="relative group">
                      {hasCritical && (
                        <span className="absolute -inset-2.5 rounded-full bg-rose-500/40 animate-ping" />
                      )}
                      <div
                        className={`relative flex items-center justify-center w-8 h-8 rounded-full shadow-lg font-extrabold text-xs ${pinTheme.bg} ${pinTheme.text} ring-4 ${pinTheme.ring} group-hover:scale-125 transition-transform`}
                      >
                        {count}
                      </div>

                      {/* Mini hover tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block bg-slate-900 text-white text-[10px] font-bold py-1 px-2.5 rounded-lg whitespace-nowrap z-30 shadow-xl pointer-events-none">
                        {loc.name} ({count} issue{count > 1 ? 's' : ''})
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pt-1">
            <span>📍 9 Managed Campus Facilities Monitored</span>
            <span className="font-medium text-indigo-700">Click any facility box or marker to preview active work orders</span>
          </div>
        </div>

        {/* Right 1 Col: Location & Issue Inspector Card / Drawer */}
        <div className="space-y-4 min-w-0">
          {selectedLocation ? (
            <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4 animate-in fade-in slide-in-from-right-2 duration-150">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-indigo-50 font-bold text-indigo-700 border border-indigo-100">
                    {selectedLocation.buildingCode}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-1">
                    {selectedLocation.name}
                  </h3>
                  <p className="text-xs text-slate-500">{selectedLocation.category}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedLocation(null)}
                  className="text-xs text-slate-400 hover:text-slate-700 font-semibold cursor-pointer p-1"
                >
                  ✕
                </button>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-2xl border border-slate-100">
                {selectedLocation.description}
              </p>

              {onReportForLocation && (
                <button
                  type="button"
                  onClick={() => onReportForLocation(selectedLocation.name)}
                  className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white text-xs font-bold shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  Report Issue At {selectedLocation.buildingCode}
                </button>
              )}

              {/* Issues at this location */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Reported Incidents ({issuesByLocation[selectedLocation.name]?.length || 0})
                  </span>
                </div>

                {issuesByLocation[selectedLocation.name] && issuesByLocation[selectedLocation.name].length > 0 ? (
                  <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                    {issuesByLocation[selectedLocation.name].map((issue) => (
                      <div
                        key={issue.id}
                        onClick={() => onOpenIssueDetail(issue)}
                        className="p-3.5 rounded-2xl bg-slate-50/80 hover:bg-indigo-50/60 border border-slate-200/80 hover:border-indigo-300 cursor-pointer transition-all space-y-2 group"
                      >
                        <div className="flex items-center justify-between">
                          <PriorityBadge priority={issue.priority} size="sm" />
                          <StatusBadge status={issue.status} size="sm" />
                        </div>
                        <h5 className="text-xs font-bold text-slate-900 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                          {issue.title}
                        </h5>
                        <p className="text-[11px] text-slate-500 line-clamp-2">
                          {issue.aiSummary || issue.description}
                        </p>
                        <div className="flex items-center justify-between text-[11px] text-indigo-600 font-bold pt-1">
                          <span>Ticket #{issue.id}</span>
                          <span className="flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                            Inspect <ChevronRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-100 text-center text-xs text-emerald-800 space-y-1">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 mx-auto" />
                    <p className="font-bold">Facility Operating Normally</p>
                    <p className="text-[11px] text-emerald-700">No active incidents logged for this building.</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-50 to-purple-50 text-indigo-600 flex items-center justify-center mx-auto border border-indigo-100">
                <Building2 className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900">Select Location or Pin</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Click on any building footprint or numeric issue marker on the campus GIS canvas to view live tickets and technician work orders.
              </p>

              {/* Quick Building Selector */}
              <div className="space-y-2 pt-2 text-left">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Quick Select Facility:
                </span>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  {locations.slice(0, 6).map((l) => (
                    <button
                      key={l.id}
                      type="button"
                      onClick={() => setSelectedLocation(l)}
                      className="p-2 rounded-xl bg-slate-50 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 text-left truncate transition-colors text-[11px] font-medium border border-slate-100"
                    >
                      {l.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
