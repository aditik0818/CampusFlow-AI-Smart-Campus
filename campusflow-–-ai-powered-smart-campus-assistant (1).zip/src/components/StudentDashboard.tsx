import React, { useState } from 'react';
import { 
  Issue, 
  Announcement, 
  ViewTab 
} from '../types';
import { 
  PlusCircle, 
  Clock, 
  AlertCircle, 
  AlertTriangle,
  CheckCircle2, 
  Layers, 
  Sparkles, 
  ArrowRight, 
  Search, 
  Filter, 
  MapPin, 
  ChevronRight, 
  Megaphone,
  ThumbsUp,
  FileText,
  Calendar,
  Zap,
  RotateCcw,
  Compass,
  PackageSearch,
  Check,
  TrendingUp,
  Eye
} from 'lucide-react';
import { PriorityBadge, StatusBadge, CategoryIcon } from './StatusBadge';
import { IssueTimeline } from './IssueTimeline';

interface StudentDashboardProps {
  issues: Issue[];
  announcements: Announcement[];
  onSelectTab: (tab: ViewTab) => void;
  onOpenIssueDetail: (issue: Issue) => void;
  onUpvoteIssue: (issueId: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  issues,
  announcements,
  onSelectTab,
  onOpenIssueDetail,
  onUpvoteIssue,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [activeKpiFilter, setActiveKpiFilter] = useState<string | null>(null);
  const [showOnlyMine, setShowOnlyMine] = useState(false);

  // Stats calculation
  const totalComplaints = issues.length;
  const pendingComplaints = issues.filter((i) => i.status === 'Submitted').length;
  const inProgressComplaints = issues.filter((i) => i.status === 'In Progress' || i.status === 'Reviewed').length;
  const resolvedComplaints = issues.filter((i) => i.status === 'Resolved').length;
  const criticalComplaints = issues.filter((i) => i.priority === 'Critical').length;

  // Resolution rate
  const resolutionRate = totalComplaints > 0 ? Math.round((resolvedComplaints / totalComplaints) * 100) : 100;

  // Most active complaint to feature on timeline
  const activeTimelineIssue = issues.find((i) => i.status !== 'Resolved') || issues[0];

  // Handle clicking a KPI card to filter complaints
  const handleKpiCardClick = (type: 'total' | 'pending' | 'in-progress' | 'resolved' | 'critical') => {
    if (activeKpiFilter === type) {
      // Toggle off
      setActiveKpiFilter(null);
      setStatusFilter('All');
      return;
    }

    setActiveKpiFilter(type);
    switch (type) {
      case 'total':
        setStatusFilter('All');
        break;
      case 'pending':
        setStatusFilter('Submitted');
        break;
      case 'in-progress':
        setStatusFilter('In Progress');
        break;
      case 'resolved':
        setStatusFilter('Resolved');
        break;
      case 'critical':
        setStatusFilter('All');
        break;
    }
  };

  const handleResetFilter = () => {
    setActiveKpiFilter(null);
    setStatusFilter('All');
    setCategoryFilter('All');
    setSearchQuery('');
    setShowOnlyMine(false);
  };

  // Filtered recent complaints
  const filteredIssues = issues.filter((issue) => {
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = categoryFilter === 'All' || issue.category === categoryFilter;
    
    let matchesStatus = true;
    if (activeKpiFilter === 'critical') {
      matchesStatus = issue.priority === 'Critical';
    } else if (statusFilter !== 'All') {
      matchesStatus = issue.status === statusFilter;
    }

    const matchesMine = !showOnlyMine || issue.studentEmail.includes('aditik') || issue.studentName.toLowerCase().includes('aditi');

    return matchesSearch && matchesCategory && matchesStatus && matchesMine;
  });

  const categories = ['All', 'Infrastructure', 'Internet/Wi-Fi', 'Cleanliness', 'Water', 'Electrical', 'Hostel', 'Transport', 'Lost & Found'];

  return (
    <div className="space-y-6 pb-12">
      {/* 4. Hero Section: Good Morning, Aditi! 👋 */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 text-white p-6 sm:p-8 lg:p-10 shadow-lg border border-indigo-800/40">
        
        {/* Subtle decorative background shapes and glows */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-72 h-72 rounded-full bg-cyan-500/15 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-12 w-80 h-80 rounded-full bg-purple-500/15 blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none opacity-40" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-6 lg:gap-10">
          
          {/* Left Text & CTAs */}
          <div className="max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 text-cyan-300 text-xs font-semibold backdrop-blur-md border border-cyan-400/20 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
              Smart Campus AI Operating System
            </div>
            
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Good Morning, Aditi! 👋
            </h1>
            
            <p className="text-sm sm:text-base text-indigo-100/90 leading-relaxed max-w-xl">
              Report issues, track progress, and help make our campus a better place. Our AI triage system analyzes tickets in real time to dispatch university technicians immediately.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                id="dash-report-btn"
                type="button"
                onClick={() => onSelectTab('report')}
                className="group inline-flex items-center gap-2.5 px-5 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-400 text-slate-950 font-bold text-sm shadow-md hover:shadow-cyan-400/25 hover:scale-[1.02] transition-all cursor-pointer"
              >
                <span>Report an Issue</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                id="dash-view-map-btn"
                type="button"
                onClick={() => onSelectTab('campus-map')}
                className="inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition-all border border-white/15 backdrop-blur-xs cursor-pointer"
              >
                <MapPin className="w-4 h-4 text-cyan-300" />
                Explore Campus Map
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowOnlyMine(!showOnlyMine);
                }}
                className={`inline-flex items-center gap-2 px-4 py-3 rounded-2xl text-xs font-semibold transition-all border ${
                  showOnlyMine
                    ? 'bg-cyan-400 text-slate-950 border-cyan-400'
                    : 'bg-white/5 hover:bg-white/10 text-indigo-200 border-white/10'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                {showOnlyMine ? 'Showing My Complaints' : 'My Complaints'}
              </button>
            </div>
          </div>

          {/* Right Campus Illustration / Visual Card */}
          <div className="w-full lg:w-80 shrink-0">
            <div className="relative rounded-2xl overflow-hidden border border-white/20 shadow-xl bg-slate-900/60 backdrop-blur-md group">
              <img
                src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=700&q=80"
                alt="University Campus Grounds"
                className="w-full h-44 object-cover object-center group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent" />
              
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-white font-medium">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>Main Quad & Tech Hub</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[10px] font-semibold text-emerald-300 border border-emerald-400/30">
                  Grid 99.4% Online
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 5. KPI Metrics Cards (5 distinct colorful cards with hover lift and click-to-filter) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Campus Infrastructure Overview
          </h2>
          {activeKpiFilter && (
            <button
              type="button"
              onClick={handleResetFilter}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              Clear Card Filter ({activeKpiFilter})
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
          
          {/* 1. Total Complaints (Indigo/Blue) */}
          <div
            onClick={() => handleKpiCardClick('total')}
            className={`p-4 sm:p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 hover:shadow-md ${
              activeKpiFilter === 'total'
                ? 'bg-gradient-to-br from-indigo-50 to-blue-50/80 border-indigo-500 ring-2 ring-indigo-200 shadow-sm'
                : 'bg-white border-slate-200/80 hover:border-indigo-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-900 tracking-wide">Total Complaints</span>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 text-white flex items-center justify-center shadow-xs">
                <Layers className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">{totalComplaints}</span>
              <div className="flex items-center gap-1 text-[11px] text-indigo-700 font-medium mt-1">
                <TrendingUp className="w-3 h-3" />
                <span>+8% this week</span>
              </div>
            </div>
          </div>

          {/* 2. Pending (Cyan/Sky) */}
          <div
            onClick={() => handleKpiCardClick('pending')}
            className={`p-4 sm:p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 hover:shadow-md ${
              activeKpiFilter === 'pending'
                ? 'bg-gradient-to-br from-cyan-50 to-sky-50/80 border-cyan-500 ring-2 ring-cyan-200 shadow-sm'
                : 'bg-white border-slate-200/80 hover:border-cyan-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-sky-900 tracking-wide">Pending Review</span>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-sky-600 text-white flex items-center justify-center shadow-xs">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-cyan-700">{pendingComplaints}</span>
              <div className="flex items-center gap-1 text-[11px] text-cyan-700 font-medium mt-1">
                <span>Awaiting dispatch</span>
              </div>
            </div>
          </div>

          {/* 3. In Progress (Amber/Orange) */}
          <div
            onClick={() => handleKpiCardClick('in-progress')}
            className={`p-4 sm:p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 hover:shadow-md ${
              activeKpiFilter === 'in-progress'
                ? 'bg-gradient-to-br from-amber-50 to-orange-50/80 border-amber-500 ring-2 ring-amber-200 shadow-sm'
                : 'bg-white border-slate-200/80 hover:border-amber-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-900 tracking-wide">In Progress</span>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-xs">
                <AlertCircle className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-amber-700">{inProgressComplaints}</span>
              <div className="flex items-center gap-1 text-[11px] text-amber-700 font-medium mt-1">
                <span>Technicians active</span>
              </div>
            </div>
          </div>

          {/* 4. Resolved (Emerald/Green) */}
          <div
            onClick={() => handleKpiCardClick('resolved')}
            className={`p-4 sm:p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 hover:shadow-md ${
              activeKpiFilter === 'resolved'
                ? 'bg-gradient-to-br from-emerald-50 to-teal-50/80 border-emerald-500 ring-2 ring-emerald-200 shadow-sm'
                : 'bg-white border-slate-200/80 hover:border-emerald-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-900 tracking-wide">Resolved</span>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-xs">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-emerald-700">{resolvedComplaints}</span>
              <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-medium mt-1">
                <span>{resolutionRate}% success rate</span>
              </div>
            </div>
          </div>

          {/* 5. Critical Issues (Rose/Pink) */}
          <div
            onClick={() => handleKpiCardClick('critical')}
            className={`p-4 sm:p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 hover:shadow-md col-span-2 sm:col-span-1 ${
              activeKpiFilter === 'critical'
                ? 'bg-gradient-to-br from-rose-50 to-pink-50/80 border-rose-500 ring-2 ring-rose-200 shadow-sm'
                : 'bg-white border-slate-200/80 hover:border-rose-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-900 tracking-wide">Critical Issues</span>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-rose-500 to-pink-600 text-white flex items-center justify-center shadow-xs">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-rose-700">{criticalComplaints}</span>
              <div className="flex items-center gap-1 text-[11px] text-rose-700 font-medium mt-1">
                <span>Urgent response</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 9. Quick Actions Interactive Grid (4 attractive cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Action 1: Report an Issue */}
        <div
          onClick={() => onSelectTab('report')}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-md hover:-translate-y-1 transition-all duration-200 cursor-pointer group flex flex-col justify-between"
        >
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center shadow-xs group-hover:scale-110 transition-transform">
              <PlusCircle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">Report an Issue</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Submit classroom equipment, Wi-Fi or lab tickets with automated AI triage.
            </p>
          </div>
          <div className="pt-3 flex items-center gap-1 text-xs font-bold text-indigo-600 group-hover:text-indigo-800">
            <span>Report Now</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Action 2: My Complaints */}
        <div
          onClick={() => {
            setShowOnlyMine(true);
            const el = document.getElementById('complaints-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-cyan-400 hover:shadow-md hover:-translate-y-1 transition-all duration-200 cursor-pointer group flex flex-col justify-between"
        >
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-xs group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">My Complaints</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Track live progress, assigned technician work orders and campus dispatch updates.
            </p>
          </div>
          <div className="pt-3 flex items-center gap-1 text-xs font-bold text-cyan-700 group-hover:text-cyan-900">
            <span>View My Tickets</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Action 3: Campus Map */}
        <div
          onClick={() => onSelectTab('campus-map')}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-emerald-400 hover:shadow-md hover:-translate-y-1 transition-all duration-200 cursor-pointer group flex flex-col justify-between"
        >
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-xs group-hover:scale-110 transition-transform">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">Campus Map</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Locate campus buildings, libraries, labs, and inspect live spatial incident markers.
            </p>
          </div>
          <div className="pt-3 flex items-center gap-1 text-xs font-bold text-emerald-700 group-hover:text-emerald-900">
            <span>Open Map</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Action 4: Lost & Found */}
        <div
          onClick={() => onSelectTab('lost-found')}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-amber-400 hover:shadow-md hover:-translate-y-1 transition-all duration-200 cursor-pointer group flex flex-col justify-between"
        >
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-xs group-hover:scale-110 transition-transform">
              <PackageSearch className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">Lost & Found</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Search misplaced items or post found keys, ID cards and devices with AI similarity matching.
            </p>
          </div>
          <div className="pt-3 flex items-center gap-1 text-xs font-bold text-amber-700 group-hover:text-amber-900">
            <span>Explore Registry</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

      </div>

      {/* Featured Complaint Live Resolution Tracker */}
      {activeTimelineIssue && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-indigo-700 uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  Live Resolution Tracker
                </span>
                <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-mono font-semibold">
                  #{activeTimelineIssue.id}
                </span>
              </div>
              <h2 className="text-lg font-bold text-slate-900 mt-1">
                {activeTimelineIssue.title}
              </h2>
              <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                <span className="flex items-center gap-1 font-medium text-slate-700">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {activeTimelineIssue.location}
                </span>
                <span>•</span>
                <span>Reported {new Date(activeTimelineIssue.createdAt).toLocaleDateString()}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <PriorityBadge priority={activeTimelineIssue.priority} />
              <StatusBadge status={activeTimelineIssue.status} />
              <button
                type="button"
                onClick={() => onOpenIssueDetail(activeTimelineIssue)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
              >
                View Details
              </button>
            </div>
          </div>

          {/* Timeline Component */}
          <div>
            <IssueTimeline
              currentStatus={activeTimelineIssue.status}
              createdAt={activeTimelineIssue.createdAt}
              updatedAt={activeTimelineIssue.updatedAt}
              resolutionDate={activeTimelineIssue.resolutionDate}
              assignedStaff={activeTimelineIssue.assignedStaff}
            />
          </div>

          {activeTimelineIssue.aiSummary && (
            <div className="p-3.5 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex items-start gap-2.5 text-xs text-slate-700">
              <Sparkles className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-indigo-950">AI Diagnostic Summary: </span>
                <span>{activeTimelineIssue.aiSummary}</span>
                <span className="ml-2 font-semibold text-indigo-700">({activeTimelineIssue.aiDepartment})</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Main Grid: Campus Complaints & Announcements */}
      <div id="complaints-section" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Interactive Recent Complaints List & Filters */}
        <div className="lg:col-span-2 space-y-4 min-w-0">
          <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">Recent Complaints & Issues</h3>
                <p className="text-xs text-slate-500">Click any complaint row to view full AI diagnosis and status timeline</p>
              </div>
              <button
                type="button"
                onClick={() => onSelectTab('report')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Report New Issue
              </button>
            </div>

            {/* 7. Complaint Status Visualization & Filtering */}
            <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-100/80 border border-slate-200/80 overflow-x-auto text-xs">
              <button
                type="button"
                onClick={() => setStatusFilter('All')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                  statusFilter === 'All'
                    ? 'bg-white text-indigo-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({issues.length})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('Submitted')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                  statusFilter === 'Submitted'
                    ? 'bg-white text-cyan-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-cyan-500" />
                Submitted ({pendingComplaints})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('In Progress')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                  statusFilter === 'In Progress'
                    ? 'bg-white text-amber-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                In Progress ({inProgressComplaints})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('Resolved')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                  statusFilter === 'Resolved'
                    ? 'bg-white text-emerald-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                Resolved ({resolvedComplaints})
              </button>
            </div>

            {/* Search & Filter Bar */}
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by issue title, building, or keyword..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition-all text-slate-800 placeholder:text-slate-400"
                />
              </div>

              {showOnlyMine && (
                <div className="flex items-center gap-1 px-3 py-2 rounded-xl bg-cyan-50 border border-cyan-200 text-cyan-800 text-xs font-semibold">
                  <span>Aditi's Tickets</span>
                  <button
                    type="button"
                    onClick={() => setShowOnlyMine(false)}
                    className="text-cyan-600 hover:text-cyan-900 ml-1"
                  >
                    ✕
                  </button>
                </div>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-3 py-1.5 rounded-full whitespace-nowrap transition-all font-medium cursor-pointer ${
                    categoryFilter === cat
                      ? 'bg-indigo-900 text-white font-semibold shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* 6. Recent Complaints List: Each row highlights on hover & opens detailed modal */}
            <div className="space-y-3 pt-2">
              {filteredIssues.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-slate-50 border border-dashed border-slate-200 space-y-2">
                  <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-sm font-semibold text-slate-700">No matching campus issues found</p>
                  <p className="text-xs text-slate-500">Try clearing filters or search query</p>
                  <button
                    type="button"
                    onClick={handleResetFilter}
                    className="mt-2 px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 text-xs font-bold hover:bg-indigo-100 transition-colors"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                filteredIssues.map((issue) => (
                  <div
                    key={issue.id}
                    onClick={() => onOpenIssueDetail(issue)}
                    className="p-4 rounded-2xl border border-slate-200/80 hover:border-indigo-400 hover:bg-indigo-50/20 hover:shadow-xs transition-all duration-150 bg-white cursor-pointer group"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <div className="p-2.5 rounded-xl bg-slate-100 text-slate-700 group-hover:bg-indigo-100 group-hover:text-indigo-700 transition-colors shrink-0">
                          <CategoryIcon category={issue.category} className="w-4 h-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[11px] font-mono text-indigo-700 font-bold">
                              #{issue.id}
                            </span>
                            <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium">
                              {issue.category}
                            </span>
                            <PriorityBadge priority={issue.priority} size="sm" />
                          </div>
                          <h4 className="text-sm font-bold text-slate-900 mt-1 group-hover:text-indigo-600 transition-colors truncate">
                            {issue.title}
                          </h4>
                          <p className="text-xs text-slate-600 line-clamp-2 mt-1">
                            {issue.description}
                          </p>

                          <div className="flex flex-wrap items-center gap-3 mt-2.5 text-xs text-slate-500">
                            <span className="flex items-center gap-1 font-medium text-slate-700 truncate">
                              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              {issue.location}
                              {issue.locationDetail && ` (${issue.locationDetail})`}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1 shrink-0">
                              <Calendar className="w-3 h-3 text-slate-400" />
                              {new Date(issue.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-2 shrink-0">
                        <StatusBadge status={issue.status} size="sm" />
                        <span className="text-xs text-indigo-600 font-bold flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                          Details <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>

                    {/* AI Department assignment note */}
                    {issue.aiDepartment && (
                      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                        <span className="flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-indigo-500" />
                          Department: <strong className="text-slate-700 font-medium">{issue.aiDepartment}</strong>
                        </span>
                        {issue.adminNotes && (
                          <span className="text-slate-500 italic max-w-xs truncate hidden sm:inline">
                            Status: {issue.adminNotes}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Campus Announcements & Quick Contacts */}
        <div className="space-y-4">
          
          {/* Announcements Card (Clickable with hover animation) */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Megaphone className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">Campus Bulletins</h3>
              </div>
              <button
                type="button"
                onClick={() => onSelectTab('announcements')}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
              >
                View all
              </button>
            </div>

            <div className="space-y-3">
              {announcements.slice(0, 3).map((ann) => (
                <div
                  key={ann.id}
                  onClick={() => onSelectTab('announcements')}
                  className="p-3.5 rounded-2xl bg-slate-50/80 hover:bg-indigo-50/50 border border-slate-100 hover:border-indigo-200 transition-all duration-150 cursor-pointer space-y-1.5 group"
                >
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-bold text-indigo-700 uppercase tracking-wide">
                      {ann.department}
                    </span>
                    <span className="text-slate-400">{ann.date}</span>
                  </div>
                  <h5 className="text-xs font-bold text-slate-900 leading-snug group-hover:text-indigo-600 transition-colors">
                    {ann.title}
                  </h5>
                  <p className="text-xs text-slate-600 line-clamp-2">
                    {ann.content}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Help & Emergency Contacts */}
          <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-3xl shadow-xs space-y-3 border border-indigo-900/30">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-cyan-300">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Campus 24/7 Dispatch</h4>
                <p className="text-[11px] text-indigo-200">Emergency & Facility Support</p>
              </div>
            </div>
            
            <div className="space-y-2 pt-1 text-xs">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/10 text-white font-mono">
                <span className="text-slate-300">Security Control Desk:</span>
                <strong className="text-cyan-300 font-bold">ext. 4444</strong>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/10 text-white font-mono">
                <span className="text-slate-300">Classroom AV Hotline:</span>
                <strong className="text-cyan-300 font-bold">ext. 5120</strong>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/10 text-white font-mono">
                <span className="text-slate-300">Medical Post:</span>
                <strong className="text-rose-300 font-bold">ext. 9110</strong>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
