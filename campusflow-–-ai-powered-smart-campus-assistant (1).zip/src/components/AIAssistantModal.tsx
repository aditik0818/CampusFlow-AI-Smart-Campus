import React, { useState, useRef, useEffect } from 'react';
import { Issue, Announcement, LostFoundItem, ChatMessage } from '../types';
import { 
  Sparkles, 
  X, 
  Send, 
  Bot, 
  User, 
  CornerDownLeft, 
  MessageSquare, 
  ChevronDown,
  Minimize2,
  Maximize2,
  RefreshCw,
  HelpCircle,
  ArrowRight
} from 'lucide-react';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  issues: Issue[];
  announcements: Announcement[];
  lostFound: LostFoundItem[];
  onNavigateToTab?: (tab: any) => void;
}

const SAMPLE_QUICK_PROMPTS = [
  'How do I report a Wi-Fi problem?',
  'Where can I report a broken classroom projector?',
  'Show my pending complaints.',
  'What should I do if I lose my ID card?',
  'Which complaints are currently unresolved?',
];

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  isOpen,
  onClose,
  issues,
  announcements,
  lostFound,
  onNavigateToTab,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'assistant',
      text: 'Hello! I am **CampusFlow AI**, your college campus assistant. Ask me how to report broken equipment, track your complaints, or search lost & found.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputValue;
    if (!query.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: query.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Gather real-time campus context to ground the AI response
      const openIssues = issues.filter((i) => i.status !== 'Resolved');
      const criticalIssues = issues.filter((i) => i.priority === 'Critical' && i.status !== 'Resolved');
      const pendingStudentIssues = issues.filter(
        (i) => i.studentEmail.includes('aditik') && i.status !== 'Resolved'
      );

      const response = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          context: {
            openIssuesCount: openIssues.length,
            resolvedCount: issues.filter((i) => i.status === 'Resolved').length,
            criticalIssues: criticalIssues.map((c) => ({
              id: c.id,
              title: c.title,
              location: c.location,
              priority: c.priority,
            })),
            pendingUserIssues: pendingStudentIssues.map((p) => ({
              id: p.id,
              title: p.title,
              status: p.status,
              assignedStaff: p.assignedStaff,
            })),
            announcements: announcements.slice(0, 3).map((a) => ({
              title: a.title,
              dept: a.department,
            })),
          },
        }),
      });

      const data = await response.json();

      const botReply: ChatMessage = {
        id: `msg-bot-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || 'I am ready to help you with any campus requests.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botReply]);
    } catch (e: any) {
      console.error('Chat error:', e);
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          sender: 'assistant',
          text: 'I had trouble connecting to the campus dispatch server. You can still report issues using the sidebar.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className={`fixed z-50 bg-white border border-slate-200/90 rounded-3xl shadow-2xl flex flex-col transition-all duration-300 overflow-hidden ${
        isExpanded
          ? 'bottom-3 right-3 left-3 sm:left-auto sm:right-6 sm:bottom-6 sm:w-[520px] max-h-[calc(100dvh-2rem)] h-[640px] max-w-[calc(100vw-1.5rem)]'
          : 'bottom-3 right-3 left-3 sm:left-auto sm:right-6 sm:bottom-6 sm:w-96 max-h-[calc(100dvh-2rem)] h-[520px] max-w-[calc(100vw-1.5rem)]'
      }`}
    >
      {/* Assistant Header */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white p-4 flex items-center justify-between select-none">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-indigo-300 border border-white/10 shadow-xs">
            <Sparkles className="w-4 h-4 text-indigo-200 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm font-bold text-white tracking-tight">CampusFlow AI</h3>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <p className="text-[10px] text-indigo-200">Smart Campus Support Assistant</p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-indigo-200">
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 hover:text-white hover:bg-white/10 rounded-lg transition-colors hidden sm:block"
            title={isExpanded ? 'Collapse view' : 'Expand view'}
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            title="Close Assistant"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/50 text-xs">
        {messages.map((msg) => {
          const isBot = msg.sender === 'assistant';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
            >
              {isBot && (
                <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                  <Bot className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 shadow-xs leading-relaxed ${
                  isBot
                    ? 'bg-white border border-slate-200/80 text-slate-800'
                    : 'bg-indigo-600 text-white rounded-br-xs'
                }`}
              >
                <div className="whitespace-pre-line text-xs font-normal">
                  {msg.text}
                </div>
                <span
                  className={`text-[9px] mt-1 block ${
                    isBot ? 'text-slate-400' : 'text-indigo-200 text-right'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>

              {!isBot && (
                <div className="w-6 h-6 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 shadow-xs mt-0.5 font-bold text-[10px]">
                  AK
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2 text-slate-500 text-xs pl-8">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
            <span>CampusFlow AI is checking campus records...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Question Chips */}
      <div className="p-2.5 bg-white border-t border-slate-100 space-y-1.5">
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-1">
          Frequently Asked Questions:
        </span>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {SAMPLE_QUICK_PROMPTS.map((prompt, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 text-[11px] whitespace-nowrap transition-colors border border-slate-200/60 shrink-0 font-medium"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3 bg-white border-t border-slate-200/80 flex items-center gap-2"
      >
        <input
          type="text"
          placeholder="Ask anything about campus facilities, lost items..."
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="flex-1 px-3.5 py-2 text-xs rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
        />
        <button
          type="submit"
          disabled={!inputValue.trim() || isLoading}
          className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-40 disabled:hover:bg-indigo-600 transition-colors shadow-xs"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
