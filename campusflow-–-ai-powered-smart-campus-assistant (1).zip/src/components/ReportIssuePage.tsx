import React, { useState, useRef } from 'react';
import { 
  Issue, 
  IssueCategory, 
  IssuePriority, 
  AIAnalysisResult, 
  CampusLocation 
} from '../types';
import { 
  Sparkles, 
  UploadCloud, 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  AlertCircle, 
  Building2, 
  ArrowRight, 
  RefreshCw, 
  HelpCircle,
  FileCheck,
  Send,
  Link,
  ChevronRight
} from 'lucide-react';
import { PriorityBadge, CategoryIcon } from './StatusBadge';

interface ReportIssuePageProps {
  locations: CampusLocation[];
  existingIssues: Issue[];
  onSubmitIssue: (newIssue: Partial<Issue>) => void;
  onSelectTab: (tab: any) => void;
  onOpenExistingIssue?: (issueId: string) => void;
}

const CATEGORIES: IssueCategory[] = [
  'Infrastructure',
  'Internet/Wi-Fi',
  'Cleanliness',
  'Water',
  'Electrical',
  'Hostel',
  'Transport',
  'Security',
  'Lost & Found',
  'Other',
];

const PRIORITIES: IssuePriority[] = ['Low', 'Medium', 'High', 'Critical'];

const COMMON_SUGGESTIONS = [
  { title: 'Projector HDMI display broken', loc: 'Academic Block', desc: 'Overhead projector in lecture hall has red error light and no video input.' },
  { title: 'Wi-Fi disconnects intermittently', loc: 'Computer Lab', desc: 'SSID dropping connection and DNS resolution fails on student workstations.' },
  { title: 'Water pipe leak in restroom', loc: 'Hostel Complex', desc: 'Overhead flush tank leaking clean water continuously onto floor creating a puddle.' },
  { title: 'Elevator door stuck open', loc: 'Hostel Complex', desc: 'Hostel elevator door jammed between floors with continuous alarm chime.' },
];

export const ReportIssuePage: React.FC<ReportIssuePageProps> = ({
  locations,
  existingIssues,
  onSubmitIssue,
  onSelectTab,
  onOpenExistingIssue,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [locationDetail, setLocationDetail] = useState('');
  const [category, setCategory] = useState<IssueCategory>('Infrastructure');
  const [priority, setPriority] = useState<IssuePriority>('Medium');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string>('image/jpeg');

  // AI Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [hasReviewedAI, setHasReviewedAI] = useState(false);

  // Form submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedIssueId, setSubmittedIssueId] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: string }>({});

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Image Upload Handling
  const handleImageChange = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setValidationErrors((prev) => ({
        ...prev,
        image: 'Unsupported file type. Please upload a PNG, JPEG, or WEBP image.',
      }));
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setValidationErrors((prev) => ({
        ...prev,
        image: 'Image size exceeds 8MB limit. Please upload a smaller image.',
      }));
      return;
    }

    setValidationErrors((prev) => {
      const copy = { ...prev };
      delete copy.image;
      return copy;
    });

    setImageMimeType(file.type);
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageChange(e.dataTransfer.files[0]);
    }
  };

  // Trigger Gemini AI Analysis
  const handleAnalyzeWithAI = async () => {
    if (!title.trim() && !description.trim()) {
      setValidationErrors((prev) => ({
        ...prev,
        description: 'Please enter an issue title or description before running AI analysis.',
      }));
      return;
    }

    setIsAnalyzing(true);
    setAnalysisError(null);

    try {
      const response = await fetch('/api/ai/analyze-issue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          location,
          imageBase64: imagePreview,
          imageMimeType,
          existingIssues,
        }),
      });

      if (!response.ok) {
        throw new Error('Analysis service returned an error. Please try again.');
      }

      const data = await response.json();

      setAiAnalysis(data);
      if (data.category && CATEGORIES.includes(data.category)) {
        setCategory(data.category);
      }
      if (data.priority && PRIORITIES.includes(data.priority)) {
        setPriority(data.priority);
      }
      setHasReviewedAI(true);
      setValidationErrors({});
    } catch (err: any) {
      console.error('AI Analysis failed:', err);
      setAnalysisError(err.message || 'Unable to complete AI triage. You can still select category and priority manually.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Form Submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: { [key: string]: string } = {};

    if (!title.trim()) {
      errors.title = 'Please enter an issue title.';
    }
    if (!description.trim() || description.trim().length < 10) {
      errors.description = 'Please provide a clear description (at least 10 characters).';
    }
    if (!location) {
      errors.location = 'Please select the campus location.';
    }

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }

    setIsSubmitting(true);

    const generatedId = `CF-2026-${Math.floor(100 + Math.random() * 900)}`;

    const newIssue: Partial<Issue> = {
      id: generatedId,
      title: title.trim(),
      description: description.trim(),
      location,
      locationDetail: locationDetail.trim() || undefined,
      category,
      priority,
      status: 'Submitted',
      imageUrl: imagePreview || undefined,
      studentName: 'Aditi Kumar',
      studentEmail: 'aditik0818@campus.edu',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      aiSummary: aiAnalysis?.summary || `${category} reported at ${location}: ${title}`,
      aiDepartment: aiAnalysis?.department || 'Campus Facilities & Operations',
      isDuplicate: aiAnalysis?.potentialDuplicate?.isDuplicate,
      duplicateOfId: aiAnalysis?.potentialDuplicate?.existingIssueId,
      adminNotes: aiAnalysis?.potentialDuplicate?.isDuplicate
        ? `Note: Flagged by AI as possible duplicate of #${aiAnalysis.potentialDuplicate.existingIssueId}.`
        : undefined,
    };

    setTimeout(() => {
      onSubmitIssue(newIssue);
      setIsSubmitting(false);
      setSubmittedIssueId(generatedId);
    }, 600);
  };

  const handleApplySuggestion = (s: { title: string; loc: string; desc: string }) => {
    setTitle(s.title);
    setLocation(s.loc);
    setDescription(s.desc);
  };

  // Success screen
  if (submittedIssueId) {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4 text-center">
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200/80 shadow-md space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-100 shadow-xs">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              Ticket Logged Successfully
            </span>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              Complaint Received & Dispatched!
            </h2>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              Your issue has been logged with reference ID <strong className="font-mono text-slate-900">#{submittedIssueId}</strong>.
              Automated routing has notified <strong className="text-indigo-700 font-semibold">{aiAnalysis?.department || 'Campus Operations'}</strong>.
            </p>
          </div>

          {/* AI triage receipt card */}
          {aiAnalysis && (
            <div className="text-left p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  AI Classification Record
                </span>
                <PriorityBadge priority={priority} size="sm" />
              </div>
              <p className="text-slate-600 leading-relaxed">
                <strong>Executive Summary:</strong> {aiAnalysis.summary}
              </p>
              <div className="flex items-center justify-between text-slate-500 pt-1 border-t border-slate-200/60">
                <span>Location: {location}</span>
                <span>Category: {category}</span>
              </div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
            <button
              type="button"
              onClick={() => onSelectTab('my-complaints')}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-xs transition-colors"
            >
              Track in My Complaints
            </button>
            <button
              type="button"
              onClick={() => {
                setSubmittedIssueId(null);
                setTitle('');
                setDescription('');
                setLocation('');
                setLocationDetail('');
                setImagePreview(null);
                setAiAnalysis(null);
                setHasReviewedAI(false);
              }}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm transition-colors"
            >
              Report Another Issue
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto w-full space-y-6 pb-12">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          Campus Incident Dispatch
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mt-1">
          Report a Campus Issue
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Provide issue details and upload an image if available. Our AI will classify the severity, summarize the problem, and dispatch it to the appropriate campus department.
        </p>
      </div>

      {/* Quick Suggestion Pills */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-2">
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Quick-Fill Common Reports:
        </span>
        <div className="flex flex-wrap gap-2">
          {COMMON_SUGGESTIONS.map((item, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleApplySuggestion(item)}
              className="px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 text-xs font-medium transition-colors"
            >
              + {item.title}
            </button>
          ))}
        </div>
      </div>

      {/* Main Reporting Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          
          {/* Issue Title */}
          <div className="space-y-1.5">
            <label htmlFor="issue-title" className="block text-sm font-bold text-slate-900">
              Issue Title <span className="text-rose-500">*</span>
            </label>
            <input
              id="issue-title"
              type="text"
              placeholder="e.g., Broken projector in Academic Block Room 302"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-sm text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 transition-all ${
                validationErrors.title
                  ? 'border-rose-300 focus:ring-rose-500 bg-rose-50/20'
                  : 'border-slate-200 focus:ring-indigo-500 focus:border-indigo-500 bg-white'
              }`}
            />
            {validationErrors.title && (
              <p className="text-xs text-rose-600 font-medium">{validationErrors.title}</p>
            )}
          </div>

          {/* Location & Detailed Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="campus-location" className="block text-sm font-bold text-slate-900">
                Campus Location <span className="text-rose-500">*</span>
              </label>
              <select
                id="campus-location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-slate-800 focus:outline-hidden focus:ring-2 transition-all ${
                  validationErrors.location
                    ? 'border-rose-300 focus:ring-rose-500 bg-rose-50/20'
                    : 'border-slate-200 focus:ring-indigo-500 focus:border-indigo-500 bg-white'
                }`}
              >
                <option value="">Select a campus facility / building...</option>
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.name}>
                    {loc.name} ({loc.buildingCode})
                  </option>
                ))}
              </select>
              {validationErrors.location && (
                <p className="text-xs text-rose-600 font-medium">{validationErrors.location}</p>
              )}
            </div>

            <div className="space-y-1.5">
              <label htmlFor="location-detail" className="block text-sm font-bold text-slate-900">
                Specific Spot / Room Details (Optional)
              </label>
              <input
                id="location-detail"
                type="text"
                placeholder="e.g., Floor 3, Room 302, Terminal row B"
                value={locationDetail}
                onChange={(e) => setLocationDetail(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
              />
            </div>
          </div>

          {/* Detailed Description */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="issue-description" className="block text-sm font-bold text-slate-900">
                Detailed Description <span className="text-rose-500">*</span>
              </label>
              <span className="text-xs text-slate-400">Be as specific as possible</span>
            </div>
            <textarea
              id="issue-description"
              rows={4}
              placeholder="Describe what happened, error codes or hazard risks, when it began, and whether any class or student is impacted..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={`w-full px-4 py-3 rounded-xl border text-sm text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 transition-all ${
                validationErrors.description
                  ? 'border-rose-300 focus:ring-rose-500 bg-rose-50/20'
                  : 'border-slate-200 focus:ring-indigo-500 focus:border-indigo-500 bg-white'
              }`}
            />
            {validationErrors.description && (
              <p className="text-xs text-rose-600 font-medium">{validationErrors.description}</p>
            )}
          </div>

          {/* Image Upload Area */}
          <div className="space-y-2">
            <label className="block text-sm font-bold text-slate-900">
              Upload Photo of Issue (Optional)
            </label>
            
            {imagePreview ? (
              <div className="relative rounded-2xl border border-slate-200 p-2 bg-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={imagePreview}
                    alt="Issue preview"
                    className="w-20 h-20 object-cover rounded-xl border border-slate-200 shadow-xs"
                  />
                  <div>
                    <p className="text-xs font-semibold text-slate-800">Attached Photo</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">Ready for AI multimodal analysis</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setImagePreview(null)}
                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-white rounded-lg transition-colors"
                  title="Remove photo"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/30 rounded-2xl p-6 text-center cursor-pointer transition-all"
              >
                <UploadCloud className="w-8 h-8 text-indigo-500 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-800">
                  Click to browse or drag and drop image here
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Supports PNG, JPEG, WEBP (up to 8MB)
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleImageChange(e.target.files[0]);
                    }
                  }}
                />
              </div>
            )}
            {validationErrors.image && (
              <p className="text-xs text-rose-600 font-medium">{validationErrors.image}</p>
            )}
          </div>

          {/* AI Analysis Action Bar */}
          <div className="pt-2">
            <button
              id="analyze-with-ai-btn"
              type="button"
              disabled={isAnalyzing || (!title.trim() && !description.trim())}
              onClick={handleAnalyzeWithAI}
              className={`w-full py-3 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-xs ${
                isAnalyzing
                  ? 'bg-indigo-400 text-white cursor-wait'
                  : !title.trim() && !description.trim()
                  ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                  : 'bg-gradient-to-r from-indigo-600 via-indigo-700 to-indigo-800 text-white hover:opacity-95'
              }`}
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Gemini AI is analyzing description & image...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-indigo-200 animate-pulse" />
                  <span>Analyze with AI (Classify, Prioritize & Check Duplicates)</span>
                </>
              )}
            </button>
          </div>

          {/* AI Analysis Result Card */}
          {aiAnalysis && (
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/70 via-white to-indigo-50/40 border border-indigo-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">AI Diagnostic Classification</h4>
                    <p className="text-[11px] text-slate-500">Verified by Google Gemini Smart Campus Model</p>
                  </div>
                </div>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-semibold">
                  Auto-Triage Active
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Detected Category */}
                <div className="p-3 bg-white rounded-xl border border-slate-200/80">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Detected Category
                  </span>
                  <div className="flex items-center gap-2 mt-1">
                    <CategoryIcon category={aiAnalysis.category} className="w-4 h-4 text-indigo-600" />
                    <span className="text-sm font-bold text-slate-900">{aiAnalysis.category}</span>
                  </div>
                </div>

                {/* Priority */}
                <div className="p-3 bg-white rounded-xl border border-slate-200/80">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Assessed Priority
                  </span>
                  <div className="mt-1">
                    <PriorityBadge priority={aiAnalysis.priority} />
                  </div>
                </div>
              </div>

              {/* AI Summary */}
              <div className="p-3.5 bg-white rounded-xl border border-slate-200/80 space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  AI Summary for Administration
                </span>
                <p className="text-xs text-slate-700 leading-relaxed font-medium">
                  {aiAnalysis.summary}
                </p>
              </div>

              {/* Recommended Department */}
              <div className="p-3.5 bg-white rounded-xl border border-slate-200/80 space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Recommended Campus Department
                </span>
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-900">
                  <Building2 className="w-4 h-4 text-indigo-600" />
                  {aiAnalysis.department}
                </div>
              </div>

              {/* Possible Duplicate Alert */}
              {aiAnalysis.potentialDuplicate && (
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 space-y-2">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span className="text-xs font-bold uppercase tracking-wider">
                      Possible Duplicate Complaint Detected ({aiAnalysis.potentialDuplicate.similarityScore}% Match)
                    </span>
                  </div>
                  <p className="text-xs text-amber-800 leading-snug">
                    {aiAnalysis.potentialDuplicate.reason ||
                      `A similar issue (#${aiAnalysis.potentialDuplicate.existingIssueId}: "${aiAnalysis.potentialDuplicate.existingIssueTitle}") is already active.`}
                  </p>
                  <p className="text-[11px] text-amber-700">
                    If this is the same incident, your report will be linked to escalate the existing work order without splitting campus technician resources.
                  </p>
                </div>
              )}

              <p className="text-[11px] text-slate-500 italic">
                You may adjust the Category or Priority below if your classroom conditions differ from the AI inference.
              </p>
            </div>
          )}

          {analysisError && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 flex items-start gap-2 text-xs">
              <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <span>{analysisError}</span>
            </div>
          )}

          {/* Student Review & Manual Overrides */}
          <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="issue-category" className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                Confirm Category
              </label>
              <select
                id="issue-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as IssueCategory)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="issue-priority" className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                Confirm Priority
              </label>
              <select
                id="issue-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value as IssuePriority)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
              >
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p} Priority
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4">
            <button
              id="submit-issue-btn"
              type="submit"
              disabled={isSubmitting}
              className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm text-white flex items-center justify-center gap-2 shadow-sm transition-all ${
                isSubmitting
                  ? 'bg-indigo-400 cursor-wait'
                  : 'bg-slate-900 hover:bg-slate-800 cursor-pointer'
              }`}
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Logging complaint into university dispatch...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Submit Verified Campus Complaint</span>
                </>
              )}
            </button>
          </div>

        </div>
      </form>
    </div>
  );
};
